package org.fmod;

import android.media.AudioTrack;
import android.util.Log;
import java.nio.ByteBuffer;

public class FMODAudioDevice implements Runnable {
    private static int i = 0;
    private static int j = 1;
    private static int k = 2;
    private static int l = 3;
    private volatile Thread a = null;
    private volatile boolean b = false;
    private volatile a c = null;
    private AudioTrack d = null;
    private boolean e = false;
    private ByteBuffer f = null;
    private byte[] g = null;
    private volatile a h;

    private class a extends Thread {
        private Object b = new Object();

        a() {
            super("FMODStreamBlocker");
        }

        /* access modifiers changed from: private */
        public void a() {
            synchronized (this.b) {
                this.b.notifyAll();
            }
        }

        public final void run() {
            if (FMODAudioDevice.this.fmodBlockStreaming() != 0) {
                throw new RuntimeException("Unable to block fmod streaming thread");
            }
            synchronized (this.b) {
                try {
                    this.b.wait();
                } catch (InterruptedException e) {
                }
            }
            if (FMODAudioDevice.this.fmodUnblockStreaming() != 0) {
                throw new RuntimeException("Unable to unblock fmod streaming thread");
            }
        }
    }

    private synchronized void blockStreaming() {
        if (isInitialized() && this.c == null) {
            this.c = new a();
            this.c.start();
        }
    }

    /* access modifiers changed from: private */
    public native int fmodBlockStreaming();

    private native int fmodGetInfo(int i2);

    private native int fmodInitJni();

    private native int fmodProcess(ByteBuffer byteBuffer);

    /* access modifiers changed from: private */
    public native int fmodUnblockStreaming();

    private void releaseAudioTrack() {
        if (this.d != null) {
            if (this.d.getState() == 1) {
                this.d.stop();
            }
            this.d.release();
            this.d = null;
        }
        this.f = null;
        this.g = null;
        this.e = false;
    }

    private synchronized void unblockStreaming() {
        if (this.c != null) {
            do {
                try {
                    this.c.a();
                    this.c.join(10);
                } catch (InterruptedException e2) {
                }
            } while (this.c.isAlive());
            this.c = null;
        }
    }

    public synchronized void close() {
        stop();
        unblockStreaming();
    }

    /* access modifiers changed from: package-private */
    public native int fmodProcessMicData(ByteBuffer byteBuffer, int i2);

    public boolean isInitialized() {
        return fmodGetInfo(i) > 0;
    }

    public boolean isRunning() {
        return this.a != null && this.a.isAlive();
    }

    public void run() {
        int i2;
        int i3 = 3;
        while (this.b) {
            if (!isInitialized()) {
                try {
                    Thread.sleep(10);
                } catch (InterruptedException e2) {
                    this.b = false;
                }
            } else {
                if (this.e || i3 <= 0) {
                    i2 = i3;
                } else {
                    releaseAudioTrack();
                    int fmodGetInfo = fmodGetInfo(i);
                    int round = Math.round(((float) AudioTrack.getMinBufferSize(fmodGetInfo, 3, 2)) * 1.1f) & -4;
                    int fmodGetInfo2 = fmodGetInfo(j);
                    int fmodGetInfo3 = fmodGetInfo(k);
                    if (fmodGetInfo2 * fmodGetInfo3 * 4 > round) {
                        round = fmodGetInfo3 * fmodGetInfo2 * 4;
                    }
                    this.d = new AudioTrack(3, fmodGetInfo, 3, 2, round, 1);
                    this.e = this.d.getState() == 1;
                    if (this.e) {
                        this.f = ByteBuffer.allocateDirect(fmodGetInfo2 * 2 * 2);
                        this.g = new byte[this.f.capacity()];
                        this.d.play();
                        i2 = 3;
                    } else {
                        Log.e("FMOD", "AudioTrack failed to initialize (status " + this.d.getState() + ")");
                        releaseAudioTrack();
                        i2 = i3 - 1;
                    }
                }
                if (!this.e) {
                    i3 = i2;
                } else if (fmodGetInfo(l) == 1) {
                    fmodProcess(this.f);
                    this.f.get(this.g, 0, this.f.capacity());
                    this.d.write(this.g, 0, this.f.capacity());
                    this.f.position(0);
                    i3 = i2;
                } else {
                    releaseAudioTrack();
                    i3 = i2;
                }
            }
        }
        releaseAudioTrack();
    }

    public synchronized void start() {
        if (this.a != null) {
            stop();
        }
        this.a = new Thread(this, "FMODAudioDevice");
        this.a.setPriority(10);
        this.b = true;
        fmodInitJni();
        unblockStreaming();
        this.a.start();
        if (this.h != null) {
            this.h.b();
        }
    }

    public synchronized int startAudioRecord(int i2, int i3, int i4) {
        if (this.h == null) {
            this.h = new a(this, i2, i3);
            this.h.b();
        }
        return this.h.a();
    }

    public synchronized void stop() {
        while (this.a != null) {
            this.b = false;
            try {
                this.a.join();
                this.a = null;
                blockStreaming();
            } catch (InterruptedException e2) {
            }
        }
        if (this.h != null) {
            this.h.c();
        }
    }

    public synchronized void stopAudioRecord() {
        if (this.h != null) {
            this.h.c();
            this.h = null;
        }
    }
}
