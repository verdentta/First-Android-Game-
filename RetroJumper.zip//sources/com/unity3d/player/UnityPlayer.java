package com.unity3d.player;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.DialogInterface;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Rect;
import android.hardware.Camera;
import android.hardware.SensorManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Environment;
import android.os.PowerManager;
import android.os.Process;
import android.provider.Settings;
import android.util.AttributeSet;
import android.view.InputEvent;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.unity3d.player.a;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;
import org.fmod.FMODAudioDevice;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

public class UnityPlayer extends FrameLayout implements a.C0128a {
    public static Activity currentActivity = null;
    private static boolean s = true;
    private String A = null;
    private NetworkInfo B = null;
    private Bundle C = new Bundle();
    private List D = new ArrayList();
    /* access modifiers changed from: private */
    public r E;
    /* access modifiers changed from: private */
    public ProgressBar F = null;
    private Runnable G = new Runnable() {
        public final void run() {
            int m = UnityPlayer.this.nativeActivityIndicatorStyle();
            if (m >= 0) {
                if (UnityPlayer.this.F == null) {
                    ProgressBar unused = UnityPlayer.this.F = new ProgressBar(UnityPlayer.this.m, (AttributeSet) null, new int[]{16842874, 16843401, 16842873, 16843400}[m]);
                    UnityPlayer.this.F.setIndeterminate(true);
                    UnityPlayer.this.F.setLayoutParams(new FrameLayout.LayoutParams(-2, -2, 51));
                    UnityPlayer.this.addView(UnityPlayer.this.F);
                }
                UnityPlayer.this.F.setVisibility(0);
                UnityPlayer.this.bringChildToFront(UnityPlayer.this.F);
            }
        }
    };
    private Runnable H = new Runnable() {
        public final void run() {
            if (UnityPlayer.this.F != null) {
                UnityPlayer.this.F.setVisibility(8);
                ProgressBar unused = UnityPlayer.this.F = null;
            }
        }
    };
    a a = new a(this, (byte) 0);
    n b = null;
    private boolean c = false;
    /* access modifiers changed from: private */
    public boolean d = false;
    /* access modifiers changed from: private */
    public boolean e = false;
    private final h f;
    /* access modifiers changed from: private */
    public final o g;
    private boolean h = false;
    /* access modifiers changed from: private */
    public q i = new q();
    private final ConcurrentLinkedQueue j = new ConcurrentLinkedQueue();
    private BroadcastReceiver k = null;
    private boolean l = false;
    /* access modifiers changed from: private */
    public ContextWrapper m;
    /* access modifiers changed from: private */
    public SurfaceView n;
    private PowerManager.WakeLock o;
    private SensorManager p;
    private WindowManager q;
    private FMODAudioDevice r;
    private boolean t;
    private boolean u = true;
    /* access modifiers changed from: private */
    public int v;
    /* access modifiers changed from: private */
    public int w;
    /* access modifiers changed from: private */
    public int x = 0;
    /* access modifiers changed from: private */
    public int y = 0;
    private final m z;

    private class a extends Thread {
        volatile boolean a;
        volatile boolean b;

        private a() {
        }

        /* synthetic */ a(UnityPlayer unityPlayer, byte b2) {
            this();
        }

        public final void a() {
            this.b = true;
            synchronized (this) {
                notify();
            }
        }

        public final void b() {
            this.a = false;
            synchronized (this) {
                notify();
            }
        }

        public final void c() {
            this.a = true;
            synchronized (this) {
                notify();
            }
        }

        /* JADX WARNING: Code restructure failed: missing block: B:30:?, code lost:
            return;
         */
        /* JADX WARNING: Exception block dominator not found, dom blocks: [] */
        /* JADX WARNING: No exception handlers in catch block: Catch:{  } */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public final void run() {
            /*
                r1 = this;
                java.lang.String r0 = "UnityMain"
                r1.setName(r0)
            L_0x0005:
                boolean r0 = r1.b     // Catch:{ InterruptedException -> 0x0031 }
                if (r0 != 0) goto L_0x0032
                monitor-enter(r1)     // Catch:{ InterruptedException -> 0x0031 }
                r1.wait()     // Catch:{ all -> 0x0033 }
                monitor-exit(r1)     // Catch:{ all -> 0x0033 }
            L_0x000e:
                boolean r0 = r1.b     // Catch:{ InterruptedException -> 0x0031 }
                if (r0 != 0) goto L_0x0005
                boolean r0 = r1.a     // Catch:{ InterruptedException -> 0x0031 }
                if (r0 != 0) goto L_0x0005
                com.unity3d.player.UnityPlayer r0 = com.unity3d.player.UnityPlayer.this     // Catch:{ InterruptedException -> 0x0031 }
                r0.executeGLThreadJobs()     // Catch:{ InterruptedException -> 0x0031 }
                com.unity3d.player.UnityPlayer r0 = com.unity3d.player.UnityPlayer.this     // Catch:{ InterruptedException -> 0x0031 }
                boolean r0 = r0.isFinishing()     // Catch:{ InterruptedException -> 0x0031 }
                if (r0 != 0) goto L_0x000e
                com.unity3d.player.UnityPlayer r0 = com.unity3d.player.UnityPlayer.this     // Catch:{ InterruptedException -> 0x0031 }
                boolean r0 = r0.nativeRender()     // Catch:{ InterruptedException -> 0x0031 }
                if (r0 != 0) goto L_0x000e
                com.unity3d.player.UnityPlayer r0 = com.unity3d.player.UnityPlayer.this     // Catch:{ InterruptedException -> 0x0031 }
                r0.b()     // Catch:{ InterruptedException -> 0x0031 }
                goto L_0x000e
            L_0x0031:
                r0 = move-exception
            L_0x0032:
                return
            L_0x0033:
                r0 = move-exception
                monitor-exit(r1)     // Catch:{ InterruptedException -> 0x0031 }
                throw r0     // Catch:{ InterruptedException -> 0x0031 }
            */
            throw new UnsupportedOperationException("Method not decompiled: com.unity3d.player.UnityPlayer.a.run():void");
        }
    }

    private abstract class b implements Runnable {
        private b() {
        }

        /* synthetic */ b(UnityPlayer unityPlayer, byte b) {
            this();
        }

        public abstract void a();

        public final void run() {
            if (!UnityPlayer.this.isFinishing()) {
                a();
            }
        }
    }

    static {
        new p().a();
        System.loadLibrary("main");
    }

    public UnityPlayer(ContextWrapper contextWrapper) {
        super(contextWrapper);
        if (contextWrapper instanceof Activity) {
            currentActivity = (Activity) contextWrapper;
        }
        this.g = new o(this);
        this.m = contextWrapper;
        this.f = contextWrapper instanceof Activity ? new k(contextWrapper) : null;
        this.z = new m(contextWrapper, this);
        a();
        a(this.m.getApplicationInfo());
        if (!q.c()) {
            AlertDialog create = new AlertDialog.Builder(this.m).setTitle("Failure to initialize!").setPositiveButton("OK", new DialogInterface.OnClickListener() {
                public final void onClick(DialogInterface dialogInterface, int i) {
                    UnityPlayer.this.b();
                }
            }).setMessage("Your hardware does not support this application, sorry!").create();
            create.setCancelable(false);
            create.show();
            return;
        }
        nativeFile(this.m.getPackageCodePath());
        k();
        this.n = new SurfaceView(contextWrapper);
        this.n.getHolder().addCallback(new SurfaceHolder.Callback() {
            public final void surfaceChanged(SurfaceHolder surfaceHolder, final int i, final int i2, final int i3) {
                UnityPlayer.this.a((b) new b() {
                    public final void a() {
                        int i = i2;
                        int i2 = i3;
                        if (!((UnityPlayer.this.x == 0 && UnityPlayer.this.y == 0) || (UnityPlayer.this.x == i && UnityPlayer.this.y == i2))) {
                            UnityPlayer.this.setScreenSize(UnityPlayer.this.x, UnityPlayer.this.y, l.a ? l.c.a() : false);
                            i = UnityPlayer.this.x;
                            i2 = UnityPlayer.this.y;
                        }
                        int unused = UnityPlayer.this.v = i;
                        int unused2 = UnityPlayer.this.w = i2;
                        UnityPlayer.this.nativeResize(UnityPlayer.this.v, UnityPlayer.this.w, UnityPlayer.this.n.getWidth(), UnityPlayer.this.n.getHeight());
                        UnityPlayer.this.h();
                    }
                });
            }

            public final void surfaceCreated(SurfaceHolder surfaceHolder) {
                Surface surface = surfaceHolder.getSurface();
                q unused = UnityPlayer.this.i;
                if (q.c()) {
                    UnityPlayer.this.nativeRecreateGfxState(surface);
                }
            }

            public final void surfaceDestroyed(SurfaceHolder surfaceHolder) {
                UnityPlayer.this.nativeRecreateGfxState((Surface) null);
            }
        });
        this.n.setFocusable(true);
        this.n.setFocusableInTouchMode(true);
        this.g.c(this.n);
        this.t = false;
        this.o = ((PowerManager) this.m.getSystemService("power")).newWakeLock(26, "Unity-VideoPlayerWakeLock");
        c();
        initJni(contextWrapper);
        nativeInitWWW(WWW.class);
        if (l.a) {
            l.c.a((View) this);
        }
        this.p = (SensorManager) this.m.getSystemService("sensor");
        this.q = (WindowManager) this.m.getSystemService("window");
        nativeSetDefaultDisplay(this.q.getDefaultDisplay().getDisplayId());
        this.a.start();
    }

    public static native void UnitySendMessage(String str, String str2, String str3);

    private static String a(String str) {
        byte[] bArr;
        try {
            MessageDigest instance = MessageDigest.getInstance("MD5");
            FileInputStream fileInputStream = new FileInputStream(str);
            long length = new File(str).length();
            fileInputStream.skip(length - Math.min(length, 65558));
            byte[] bArr2 = new byte[1024];
            for (int i2 = 0; i2 != -1; i2 = fileInputStream.read(bArr2)) {
                instance.update(bArr2, 0, i2);
            }
            bArr = instance.digest();
        } catch (FileNotFoundException e2) {
            bArr = null;
        } catch (IOException e3) {
            bArr = null;
        } catch (NoSuchAlgorithmException e4) {
            bArr = null;
        }
        if (bArr == null) {
            return null;
        }
        StringBuffer stringBuffer = new StringBuffer();
        for (byte b2 : bArr) {
            stringBuffer.append(Integer.toString((b2 & 255) + 256, 16).substring(1));
        }
        return stringBuffer.toString();
    }

    private void a() {
        try {
            File file = new File(this.m.getPackageCodePath(), "assets/bin/Data/settings.xml");
            InputStream fileInputStream = file.exists() ? new FileInputStream(file) : this.m.getAssets().open("bin/Data/settings.xml");
            XmlPullParserFactory newInstance = XmlPullParserFactory.newInstance();
            newInstance.setNamespaceAware(true);
            XmlPullParser newPullParser = newInstance.newPullParser();
            newPullParser.setInput(fileInputStream, (String) null);
            String str = null;
            String str2 = null;
            for (int eventType = newPullParser.getEventType(); eventType != 1; eventType = newPullParser.next()) {
                if (eventType == 2) {
                    str2 = newPullParser.getName();
                    String str3 = str;
                    for (int i2 = 0; i2 < newPullParser.getAttributeCount(); i2++) {
                        if (newPullParser.getAttributeName(i2).equalsIgnoreCase("name")) {
                            str3 = newPullParser.getAttributeValue(i2);
                        }
                    }
                    str = str3;
                } else if (eventType == 3) {
                    str2 = null;
                } else if (eventType == 4 && str != null) {
                    if (str2.equalsIgnoreCase("integer")) {
                        this.C.putInt(str, Integer.parseInt(newPullParser.getText()));
                    } else if (str2.equalsIgnoreCase("string")) {
                        this.C.putString(str, newPullParser.getText());
                    } else if (str2.equalsIgnoreCase("bool")) {
                        this.C.putBoolean(str, Boolean.parseBoolean(newPullParser.getText()));
                    } else if (str2.equalsIgnoreCase("float")) {
                        this.C.putFloat(str, Float.parseFloat(newPullParser.getText()));
                    }
                    str = null;
                }
            }
        } catch (Exception e2) {
            i.Log(6, "Unable to locate player settings. " + e2.getLocalizedMessage());
            b();
        }
    }

    private static void a(ApplicationInfo applicationInfo) {
        if (NativeLoader.load(applicationInfo.nativeLibraryDir)) {
            q.a();
            return;
        }
        throw new UnsatisfiedLinkError("Unable to load libraries from libmain.so");
    }

    /* access modifiers changed from: private */
    public void a(b bVar) {
        if (!isFinishing()) {
            c((Runnable) bVar);
        }
    }

    static void a(Runnable runnable) {
        new Thread(runnable).start();
    }

    private static void a(String str, PowerManager.WakeLock wakeLock, boolean z2) {
        try {
            if (z2 != wakeLock.isHeld()) {
                if (z2) {
                    wakeLock.acquire();
                    if (!wakeLock.isHeld()) {
                        i.Log(5, String.format("Unable to acquire %s wake-lock. Make sure 'android.permission.WAKE_LOCK' has been set in the manifest.", new Object[]{str}));
                    }
                } else if (!z2) {
                    wakeLock.release();
                }
            }
        } catch (Exception e2) {
            i.Log(5, String.format("Unable to acquire/release %s wake-lock. Make sure 'android.permission.WAKE_LOCK' has been set in the manifest.", new Object[]{str}));
        }
    }

    /* access modifiers changed from: private */
    public void a(boolean z2) {
        a("video", this.o, z2);
    }

    private boolean a(KeyEvent keyEvent) {
        int keyCode = keyEvent.getKeyCode();
        if (keyCode == 25 || keyCode == 24) {
            return false;
        }
        final KeyEvent keyEvent2 = new KeyEvent(keyEvent);
        a((b) new b() {
            public final void a() {
                boolean unused = UnityPlayer.this.nativeInjectEvent(keyEvent2);
            }
        });
        return true;
    }

    private boolean a(MotionEvent motionEvent) {
        if (this.l) {
            return false;
        }
        final MotionEvent obtain = MotionEvent.obtain(motionEvent);
        a((b) new b() {
            public final void a() {
                boolean unused = UnityPlayer.this.nativeInjectEvent(obtain);
                obtain.recycle();
            }
        });
        return true;
    }

    private static String[] a(Context context) {
        String packageName = context.getPackageName();
        Vector vector = new Vector();
        try {
            int i2 = context.getPackageManager().getPackageInfo(packageName, 0).versionCode;
            if (Environment.getExternalStorageState().equals("mounted")) {
                File file = new File(Environment.getExternalStorageDirectory().toString() + "/Android/obb/" + packageName);
                if (file.exists()) {
                    if (i2 > 0) {
                        String str = file + File.separator + "main." + i2 + "." + packageName + ".obb";
                        if (new File(str).isFile()) {
                            vector.add(str);
                        }
                    }
                    if (i2 > 0) {
                        String str2 = file + File.separator + "patch." + i2 + "." + packageName + ".obb";
                        if (new File(str2).isFile()) {
                            vector.add(str2);
                        }
                    }
                }
            }
            String[] strArr = new String[vector.size()];
            vector.toArray(strArr);
            return strArr;
        } catch (PackageManager.NameNotFoundException e2) {
            return new String[0];
        }
    }

    /* access modifiers changed from: private */
    public void b() {
        if ((this.m instanceof Activity) && !((Activity) this.m).isFinishing()) {
            ((Activity) this.m).finish();
        }
    }

    private void b(Runnable runnable) {
        if (this.m instanceof Activity) {
            ((Activity) this.m).runOnUiThread(runnable);
        } else {
            i.Log(5, "Not running Unity from an Activity; ignored...");
        }
    }

    private void c() {
        boolean a2 = new j((Activity) this.m).a();
        this.l = a2;
        nativeForwardEventsToDalvik(a2);
    }

    private void c(Runnable runnable) {
        q qVar = this.i;
        if (q.c()) {
            if (Thread.currentThread() == this.a) {
                runnable.run();
            } else {
                this.j.add(runnable);
            }
        }
    }

    private void d() {
        for (a c2 : this.D) {
            c2.c();
        }
    }

    private void e() {
        for (a aVar : this.D) {
            try {
                aVar.a((a.C0128a) this);
            } catch (Exception e2) {
                i.Log(6, "Unable to initialize camera: " + e2.getMessage());
                aVar.c();
            }
        }
    }

    /* access modifiers changed from: private */
    public void f() {
        if (this.r != null) {
            this.r.close();
        }
        nativeDone();
    }

    private void g() {
        if (this.i.e()) {
            if (this.E != null) {
                a(true);
                this.E.onResume();
                return;
            }
            this.i.c(true);
            e();
            this.a.b();
            this.z.e();
            this.A = null;
            this.B = null;
            q qVar = this.i;
            if (q.c()) {
                k();
            }
            c((Runnable) new Runnable() {
                public final void run() {
                    UnityPlayer.this.nativeResume();
                }
            });
            if (s && this.r == null) {
                this.r = new FMODAudioDevice();
            }
            if (this.r != null && !this.r.isRunning()) {
                this.r.start();
            }
        }
    }

    /* access modifiers changed from: private */
    public void h() {
        if (this.m instanceof Activity) {
            float f2 = BitmapDescriptorFactory.HUE_RED;
            if (!this.C.getBoolean("hide_status_bar", true)) {
                Rect rect = new Rect();
                ((Activity) this.m).getWindow().getDecorView().getWindowVisibleDisplayFrame(rect);
                f2 = (float) rect.top;
            }
            nativeSetTouchDeltaY(f2);
        }
    }

    private static void i() {
        if (q.c()) {
            if (!NativeLoader.unload()) {
                throw new UnsatisfiedLinkError("Unable to unload libraries from libmain.so");
            }
            q.b();
        }
    }

    private final native void initJni(Context context);

    private boolean j() {
        return this.m.getPackageManager().hasSystemFeature("android.hardware.camera") || this.m.getPackageManager().hasSystemFeature("android.hardware.camera.front");
    }

    private void k() {
        if (this.C.getBoolean("useObb")) {
            for (String str : a((Context) this.m)) {
                String a2 = a(str);
                if (this.C.getBoolean(a2)) {
                    nativeFile(str);
                }
                this.C.remove(a2);
            }
        }
    }

    /* access modifiers changed from: private */
    public final native int nativeActivityIndicatorStyle();

    private final native void nativeDone();

    private final native void nativeFile(String str);

    /* access modifiers changed from: private */
    public final native void nativeFocusChanged(boolean z2);

    private final native void nativeInitWWW(Class cls);

    /* access modifiers changed from: private */
    public final native boolean nativeInjectEvent(InputEvent inputEvent);

    /* access modifiers changed from: private */
    public final native boolean nativePause();

    /* access modifiers changed from: private */
    public final native void nativeRecreateGfxState(Surface surface);

    /* access modifiers changed from: private */
    public final native boolean nativeRender();

    private final native boolean nativeRequested32bitDisplayBuffer();

    private final native int nativeRequestedAA();

    /* access modifiers changed from: private */
    public final native void nativeResize(int i2, int i3, int i4, int i5);

    /* access modifiers changed from: private */
    public final native void nativeResume();

    private final native void nativeSetDefaultDisplay(int i2);

    private final native void nativeSetExtras(Bundle bundle);

    /* access modifiers changed from: private */
    public final native void nativeSetInputCanceled(boolean z2);

    /* access modifiers changed from: private */
    public final native void nativeSetInputString(String str);

    private final native void nativeSetTouchDeltaY(float f2);

    /* access modifiers changed from: private */
    public final native void nativeSoftInputClosed();

    /* access modifiers changed from: private */
    public final native void nativeVideoFrameCallback(int i2, byte[] bArr, int i3, int i4);

    /* access modifiers changed from: protected */
    public boolean Location_IsServiceEnabledByUser() {
        return this.z.a();
    }

    /* access modifiers changed from: protected */
    public void Location_SetDesiredAccuracy(float f2) {
        this.z.b(f2);
    }

    /* access modifiers changed from: protected */
    public void Location_SetDistanceFilter(float f2) {
        this.z.a(f2);
    }

    /* access modifiers changed from: protected */
    public void Location_StartUpdatingLocation() {
        this.z.b();
    }

    /* access modifiers changed from: protected */
    public void Location_StopUpdatingLocation() {
        this.z.c();
    }

    /* access modifiers changed from: protected */
    public void closeCamera(int i2) {
        for (a aVar : this.D) {
            if (aVar.a() == i2) {
                aVar.c();
                this.D.remove(aVar);
                return;
            }
        }
    }

    public void configurationChanged(Configuration configuration) {
        if (this.n instanceof SurfaceView) {
            this.n.getHolder().setSizeFromLayout();
        }
        if (this.e && configuration.hardKeyboardHidden == 2) {
            ((InputMethodManager) this.m.getSystemService("input_method")).toggleSoftInput(0, 1);
        }
        if (this.E != null) {
            this.E.updateVideoLayout();
        }
    }

    /* access modifiers changed from: protected */
    public void disableLogger() {
        i.a = true;
    }

    /* access modifiers changed from: protected */
    public void executeGLThreadJobs() {
        while (true) {
            Runnable runnable = (Runnable) this.j.poll();
            if (runnable != null) {
                runnable.run();
            } else {
                return;
            }
        }
    }

    /* access modifiers changed from: protected */
    public void forwardMotionEventToDalvik(long j2, long j3, int i2, int i3, int[] iArr, float[] fArr, int i4, float f2, float f3, int i5, int i6, int i7, int i8, int i9, long[] jArr, float[] fArr2) {
        this.f.a(j2, j3, i2, i3, iArr, fArr, i4, f2, f3, i5, i6, i7, i8, i9, jArr, fArr2);
    }

    /* access modifiers changed from: protected */
    public int getCameraOrientation(int i2) {
        Camera.CameraInfo cameraInfo = new Camera.CameraInfo();
        Camera.getCameraInfo(i2, cameraInfo);
        return cameraInfo.orientation;
    }

    /* access modifiers changed from: protected */
    public int getInternetReachability() {
        try {
            if (this.B == null) {
                this.B = ((ConnectivityManager) this.m.getSystemService("connectivity")).getActiveNetworkInfo();
            }
            NetworkInfo networkInfo = this.B;
            if (networkInfo == null) {
                return 0;
            }
            if (!networkInfo.isConnected()) {
                return 0;
            }
            return networkInfo.getType() + 1;
        } catch (Exception e2) {
            i.Log(5, "android.permission.ACCESS_NETWORK_STATE not available?");
            return 0;
        }
    }

    /* access modifiers changed from: protected */
    public int getNumCameras() {
        if (!j()) {
            return 0;
        }
        return Camera.getNumberOfCameras();
    }

    /* access modifiers changed from: protected */
    public int getScreenTimeout() {
        return Settings.System.getInt(this.m.getContentResolver(), "screen_off_timeout", 15000) / 1000;
    }

    public Bundle getSettings() {
        return this.C;
    }

    /* access modifiers changed from: protected */
    public int getSplashMode() {
        return this.C.getInt("splash_mode");
    }

    public View getView() {
        return this;
    }

    /* access modifiers changed from: protected */
    public void hideSoftInput() {
        b((Runnable) new Runnable() {
            public final void run() {
                if (UnityPlayer.this.e) {
                    ((InputMethodManager) UnityPlayer.this.m.getSystemService("input_method")).toggleSoftInput(1, 0);
                    boolean unused = UnityPlayer.this.e = false;
                } else if (UnityPlayer.this.b != null) {
                    UnityPlayer.this.b.dismiss();
                    UnityPlayer.this.b = null;
                }
            }
        });
    }

    /* access modifiers changed from: protected */
    public void hideVideoPlayer() {
        b((Runnable) new Runnable() {
            public final void run() {
                if (UnityPlayer.this.E != null) {
                    UnityPlayer.this.g.c(UnityPlayer.this.n);
                    UnityPlayer.this.removeView(UnityPlayer.this.E);
                    r unused = UnityPlayer.this.E = null;
                    UnityPlayer.this.resume();
                    UnityPlayer.this.a(false);
                }
            }
        });
    }

    public void init(int i2, boolean z2) {
    }

    /* access modifiers changed from: protected */
    public int[] initCamera(int i2, int i3, int i4, int i5) {
        a aVar = new a(i2, i3, i4, i5);
        try {
            aVar.a((a.C0128a) this);
            this.D.add(aVar);
            Camera.Size b2 = aVar.b();
            return new int[]{b2.width, b2.height};
        } catch (Exception e2) {
            i.Log(6, "Unable to initialize camera: " + e2.getMessage());
            aVar.c();
            return null;
        }
    }

    public boolean injectEvent(InputEvent inputEvent) {
        if (inputEvent instanceof KeyEvent) {
            return a((KeyEvent) inputEvent);
        }
        if (inputEvent instanceof MotionEvent) {
            return a((MotionEvent) inputEvent);
        }
        i.Log(3, String.format("Dropping unknown event type '%s'", new Object[]{inputEvent}));
        return false;
    }

    /* access modifiers changed from: protected */
    public boolean isCameraFrontFacing(int i2) {
        Camera.CameraInfo cameraInfo = new Camera.CameraInfo();
        Camera.getCameraInfo(i2, cameraInfo);
        return cameraInfo.facing == 1;
    }

    /* access modifiers changed from: protected */
    public boolean isFinishing() {
        if (!this.t) {
            boolean z2 = (this.m instanceof Activity) && ((Activity) this.m).isFinishing();
            this.t = z2;
            if (!z2) {
                return false;
            }
        }
        return true;
    }

    /* access modifiers changed from: protected */
    public void kill() {
        Process.killProcess(Process.myPid());
    }

    /* access modifiers changed from: protected */
    public boolean loadLibrary(String str) {
        try {
            System.loadLibrary(str);
            return true;
        } catch (UnsatisfiedLinkError e2) {
            i.Log(6, "Unable to find " + str);
            return false;
        } catch (Exception e3) {
            i.Log(6, "Unknown error " + e3);
            return false;
        }
    }

    /* access modifiers changed from: package-private */
    public final native void nativeDeviceOrientation(int i2);

    /* access modifiers changed from: package-private */
    public final native void nativeForwardEventsToDalvik(boolean z2);

    /* access modifiers changed from: protected */
    public native void nativeSetLocation(float f2, float f3, float f4, float f5, double d2, float f6);

    /* access modifiers changed from: protected */
    public native void nativeSetLocationStatus(int i2);

    public void onCameraFrame(a aVar, byte[] bArr) {
        final int a2 = aVar.a();
        final Camera.Size b2 = aVar.b();
        final byte[] bArr2 = bArr;
        final a aVar2 = aVar;
        a((b) new b() {
            public final void a() {
                UnityPlayer.this.nativeVideoFrameCallback(a2, bArr2, b2.width, b2.height);
                aVar2.a(bArr2);
            }
        });
    }

    public boolean onGenericMotionEvent(MotionEvent motionEvent) {
        return a(motionEvent);
    }

    public boolean onKeyDown(int i2, KeyEvent keyEvent) {
        return a(keyEvent);
    }

    public boolean onKeyMultiple(int i2, int i3, KeyEvent keyEvent) {
        return a(keyEvent);
    }

    public boolean onKeyPreIme(int i2, KeyEvent keyEvent) {
        if (!this.e || i2 != 4) {
            return false;
        }
        return a(keyEvent);
    }

    public boolean onKeyUp(int i2, KeyEvent keyEvent) {
        return a(keyEvent);
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        return a(motionEvent);
    }

    public void pause() {
        if (this.E != null) {
            this.E.onPause();
            a(false);
            return;
        }
        reportSoftInputStr((String) null, 1, true);
        q qVar = this.i;
        if (q.c()) {
            final Semaphore semaphore = new Semaphore(0);
            if (isFinishing()) {
                c((Runnable) new Runnable() {
                    public final void run() {
                        UnityPlayer.this.f();
                        semaphore.release();
                    }
                });
            } else {
                c((Runnable) new Runnable() {
                    public final void run() {
                        if (UnityPlayer.this.nativePause()) {
                            UnityPlayer.this.f();
                            semaphore.release(2);
                            return;
                        }
                        semaphore.release();
                    }
                });
            }
            try {
                semaphore.tryAcquire(10, TimeUnit.SECONDS);
            } catch (InterruptedException e2) {
            }
            if (semaphore.drainPermits() > 0) {
                quit();
            }
        }
        if (this.i.f()) {
            this.i.c(false);
            this.i.b(true);
            d();
            if (this.r != null) {
                this.r.stop();
            }
            this.a.c();
            this.z.d();
        }
    }

    public void quit() {
        this.t = true;
        if (!this.i.d()) {
            pause();
        }
        this.a.a();
        try {
            this.a.join(10000);
        } catch (InterruptedException e2) {
        }
        if (this.k != null) {
            this.m.unregisterReceiver(this.k);
        }
        this.k = null;
        if (q.c()) {
            removeAllViews();
        }
        i();
        kill();
    }

    /* access modifiers changed from: protected */
    public void reportSoftInputStr(final String str, final int i2, final boolean z2) {
        if (i2 == 1) {
            hideSoftInput();
        }
        a((b) new b() {
            public final void a() {
                if (z2) {
                    UnityPlayer.this.nativeSetInputCanceled(true);
                } else if (str != null) {
                    UnityPlayer.this.nativeSetInputString(str);
                }
                if (i2 == 1) {
                    UnityPlayer.this.nativeSoftInputClosed();
                }
            }
        });
    }

    /* access modifiers changed from: protected */
    public void restartFMODAudioDevice() {
        this.r.stop();
        this.r.start();
    }

    public void resume() {
        if (l.a) {
            l.c.b(this);
        }
        this.i.b(false);
        g();
    }

    /* access modifiers changed from: protected */
    public void setHideInputField(boolean z2) {
        this.d = z2;
    }

    /* access modifiers changed from: protected */
    public void setScreenSize(int i2, int i3, boolean z2) {
        final boolean z3 = true;
        final SurfaceView surfaceView = this.n;
        surfaceView.getHolder().getSurfaceFrame();
        final boolean z4 = (surfaceView.getWidth() == i2 && surfaceView.getHeight() == i3) || (i2 == 0 && i3 == 0);
        if (!(i2 == -1 && i3 == -1)) {
            z3 = false;
        }
        if (!z3) {
            if (z4) {
                this.x = 0;
                this.y = 0;
            } else {
                this.x = i2;
                this.y = i3;
            }
        } else if (this.x == 0) {
            int i4 = this.y;
        }
        final int i5 = i2;
        final int i6 = i3;
        final boolean z5 = z2;
        b((Runnable) new Runnable() {
            public final void run() {
                if (!z3) {
                    if (z4) {
                        surfaceView.getHolder().setSizeFromLayout();
                    } else {
                        surfaceView.getHolder().setFixedSize(i5, i6);
                    }
                    surfaceView.invalidate();
                }
                if (l.a) {
                    l.c.a(UnityPlayer.this, z5);
                }
            }
        });
    }

    /* access modifiers changed from: protected */
    public void setSoftInputStr(final String str) {
        b((Runnable) new Runnable() {
            public final void run() {
                if (UnityPlayer.this.b != null && str != null) {
                    UnityPlayer.this.b.a(str);
                }
            }
        });
    }

    /* access modifiers changed from: protected */
    public void showSoftInput(String str, int i2, boolean z2, boolean z3, boolean z4, boolean z5, String str2) {
        final String str3 = str;
        final int i3 = i2;
        final boolean z6 = z2;
        final boolean z7 = z3;
        final boolean z8 = z4;
        final boolean z9 = z5;
        final String str4 = str2;
        b((Runnable) new Runnable() {
            public final void run() {
                if (UnityPlayer.this.d) {
                    ((InputMethodManager) this.m.getSystemService("input_method")).toggleSoftInput(0, 1);
                    boolean unused = UnityPlayer.this.e = true;
                    return;
                }
                UnityPlayer unityPlayer = UnityPlayer.this;
                ContextWrapper o = UnityPlayer.this.m;
                UnityPlayer unityPlayer2 = this;
                String str = str3;
                int i2 = i3;
                boolean z = z6;
                boolean z2 = z7;
                boolean z3 = z8;
                boolean z4 = z9;
                unityPlayer.b = new n(o, unityPlayer2, str, i2, z, z2, z3, str4);
                UnityPlayer.this.b.show();
            }
        });
    }

    /* access modifiers changed from: protected */
    public void showVideoPlayer(String str, int i2, int i3, int i4, boolean z2, int i5, int i6) {
        final String str2 = str;
        final int i7 = i2;
        final int i8 = i3;
        final int i9 = i4;
        final boolean z3 = z2;
        final int i10 = i5;
        final int i11 = i6;
        b((Runnable) new Runnable() {
            public final void run() {
                if (UnityPlayer.this.E == null) {
                    UnityPlayer.this.a(true);
                    UnityPlayer.this.pause();
                    r unused = UnityPlayer.this.E = new r(UnityPlayer.this, UnityPlayer.this.m, str2, i7, i8, i9, z3, (long) i10, (long) i11);
                    UnityPlayer.this.addView(UnityPlayer.this.E);
                    UnityPlayer.this.E.requestFocus();
                    UnityPlayer.this.g.d(UnityPlayer.this.n);
                }
            }
        });
    }

    /* access modifiers changed from: protected */
    public void startActivityIndicator() {
        b(this.G);
    }

    /* access modifiers changed from: protected */
    public void stopActivityIndicator() {
        b(this.H);
    }

    /* access modifiers changed from: protected */
    public void triggerResizeCall() {
        nativeResize(this.v, this.w, this.v, this.w);
    }

    public void windowFocusChanged(final boolean z2) {
        this.i.a(z2);
        if (z2 && this.b != null) {
            reportSoftInputStr((String) null, 1, false);
        }
        c((Runnable) new Runnable() {
            public final void run() {
                UnityPlayer.this.nativeFocusChanged(z2);
            }
        });
        g();
    }
}
