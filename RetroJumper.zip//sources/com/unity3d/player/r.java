package com.unity3d.player;

import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.util.Log;
import android.view.Display;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.MediaController;
import java.io.FileInputStream;
import java.io.IOException;

public final class r extends FrameLayout implements SensorEventListener, MediaPlayer.OnBufferingUpdateListener, MediaPlayer.OnCompletionListener, MediaPlayer.OnPreparedListener, MediaPlayer.OnVideoSizeChangedListener, SurfaceHolder.Callback, MediaController.MediaPlayerControl {
    private static final boolean A;
    private static boolean a = false;
    /* access modifiers changed from: private */
    public final UnityPlayer b;
    private final Context c;
    private final SurfaceView d;
    private final SurfaceHolder e;
    private final String f;
    private final int g;
    private final int h;
    private final boolean i;
    private final long j;
    private final long k;
    private final FrameLayout l;
    private final SensorManager m;
    private final Display n;
    private int o;
    private int p;
    private int q;
    private int r;
    private MediaPlayer s;
    private MediaController t;
    private boolean u = false;
    private boolean v = false;
    private int w = 0;
    private boolean x = false;
    private int y = 0;
    private boolean z;

    static {
        boolean z2 = false;
        if (Build.MANUFACTURER.equalsIgnoreCase("Amazon") && (Build.MODEL.equalsIgnoreCase("KFTT") || Build.MODEL.equalsIgnoreCase("KFJWI") || Build.MODEL.equalsIgnoreCase("KFJWA") || Build.MODEL.equalsIgnoreCase("KFSOWI") || Build.MODEL.equalsIgnoreCase("KFTHWA") || Build.MODEL.equalsIgnoreCase("KFTHWI") || Build.MODEL.equalsIgnoreCase("KFAPWA") || Build.MODEL.equalsIgnoreCase("KFAPWI"))) {
            z2 = true;
        }
        A = z2;
    }

    protected r(UnityPlayer unityPlayer, Context context, String str, int i2, int i3, int i4, boolean z2, long j2, long j3) {
        super(context);
        this.b = unityPlayer;
        this.c = context;
        this.l = this;
        this.d = new SurfaceView(context);
        this.e = this.d.getHolder();
        this.e.addCallback(this);
        this.e.setType(3);
        this.l.setBackgroundColor(i2);
        this.l.addView(this.d);
        this.m = (SensorManager) this.c.getSystemService("sensor");
        this.n = ((WindowManager) this.c.getSystemService("window")).getDefaultDisplay();
        this.f = str;
        this.g = i3;
        this.h = i4;
        this.i = z2;
        this.j = j2;
        this.k = j3;
        if (a) {
            a("fileName: " + this.f);
        }
        if (a) {
            a("backgroundColor: " + i2);
        }
        if (a) {
            a("controlMode: " + this.g);
        }
        if (a) {
            a("scalingMode: " + this.h);
        }
        if (a) {
            a("isURL: " + this.i);
        }
        if (a) {
            a("videoOffset: " + this.j);
        }
        if (a) {
            a("videoLength: " + this.k);
        }
        setFocusable(true);
        setFocusableInTouchMode(true);
        this.m.registerListener(this, this.m.getDefaultSensor(1), 1);
        this.z = true;
    }

    private void a() {
        doCleanUp();
        try {
            this.s = new MediaPlayer();
            if (this.i) {
                this.s.setDataSource(this.c, Uri.parse(this.f));
            } else if (this.k != 0) {
                FileInputStream fileInputStream = new FileInputStream(this.f);
                this.s.setDataSource(fileInputStream.getFD(), this.j, this.k);
                fileInputStream.close();
            } else {
                try {
                    AssetFileDescriptor openFd = getResources().getAssets().openFd(this.f);
                    this.s.setDataSource(openFd.getFileDescriptor(), openFd.getStartOffset(), openFd.getLength());
                    openFd.close();
                } catch (IOException e2) {
                    FileInputStream fileInputStream2 = new FileInputStream(this.f);
                    this.s.setDataSource(fileInputStream2.getFD());
                    fileInputStream2.close();
                }
            }
            this.s.setDisplay(this.e);
            this.s.setOnBufferingUpdateListener(this);
            this.s.setOnCompletionListener(this);
            this.s.setOnPreparedListener(this);
            this.s.setOnVideoSizeChangedListener(this);
            this.s.setAudioStreamType(3);
            this.s.prepare();
            if (this.g == 0 || this.g == 1) {
                this.t = new MediaController(this.c);
                this.t.setMediaPlayer(this);
                this.t.setAnchorView(this.d);
                this.t.setEnabled(true);
                this.t.show();
            }
        } catch (Exception e3) {
            if (a) {
                a("error: " + e3.getMessage() + e3);
            }
            onDestroy();
        }
    }

    private static void a(String str) {
        Log.v("Video", str);
    }

    private void b() {
        if (!isPlaying()) {
            if (a) {
                a("startVideoPlayback");
            }
            updateVideoLayout();
            if (!this.x) {
                start();
            }
        }
    }

    public static int calculateDeviceOrientation(SensorEvent sensorEvent, Display display) {
        float f2;
        int i2;
        float f3;
        int i3;
        float f4;
        float f5 = sensorEvent.values[0];
        float f6 = sensorEvent.values[1];
        float f7 = sensorEvent.values[2];
        float sqrt = 1.0f / ((float) Math.sqrt((double) (((f5 * f5) + (f6 * f6)) + (f7 * f7))));
        float f8 = f5 * sqrt;
        float f9 = f6 * sqrt;
        float f10 = f7 * sqrt;
        if (((display.getOrientation() & 1) == 0) ^ (display.getHeight() > display.getWidth())) {
            f2 = -f8;
        } else {
            float f11 = f9;
            f9 = f8;
            f2 = f11;
        }
        float f12 = A ? -f9 : f9;
        if (-1.0f < f2) {
            i2 = 1;
            f3 = f2;
        } else {
            i2 = 0;
            f3 = -1.0f;
        }
        if (f3 < (-f2)) {
            f4 = -f2;
            i3 = 2;
        } else {
            i3 = i2;
            f4 = f3;
        }
        if (f4 < f12) {
            i3 = 3;
            f4 = f12;
        }
        if (f4 < (-f12)) {
            f4 = -f12;
            i3 = 4;
        }
        if (f4 < f10) {
            i3 = 5;
            f4 = f10;
        }
        if (f4 < (-f10)) {
            f4 = -f10;
            i3 = 6;
        }
        if (((double) f4) < 0.5d * Math.sqrt(3.0d)) {
            return 0;
        }
        return i3;
    }

    public final boolean canPause() {
        return true;
    }

    public final boolean canSeekBackward() {
        return true;
    }

    public final boolean canSeekForward() {
        return true;
    }

    /* access modifiers changed from: protected */
    public final void doCleanUp() {
        if (this.s != null) {
            this.s.release();
            this.s = null;
        }
        this.q = 0;
        this.r = 0;
        this.v = false;
        this.u = false;
    }

    public final int getBufferPercentage() {
        if (this.i) {
            return this.w;
        }
        return 100;
    }

    public final int getCurrentPosition() {
        if (this.s == null) {
            return 0;
        }
        return this.s.getCurrentPosition();
    }

    public final int getDuration() {
        if (this.s == null) {
            return 0;
        }
        return this.s.getDuration();
    }

    public final boolean isPlaying() {
        boolean z2 = this.v && this.u;
        return this.s == null ? !z2 : this.s.isPlaying() || !z2;
    }

    public final void onAccuracyChanged(Sensor sensor, int i2) {
    }

    public final void onBufferingUpdate(MediaPlayer mediaPlayer, int i2) {
        if (a) {
            a("onBufferingUpdate percent:" + i2);
        }
        this.w = i2;
    }

    public final void onCompletion(MediaPlayer mediaPlayer) {
        if (a) {
            a("onCompletion called");
        }
        onDestroy();
    }

    public final void onControllerHide() {
    }

    /* access modifiers changed from: protected */
    public final void onDestroy() {
        onPause();
        doCleanUp();
        UnityPlayer unityPlayer = this.b;
        UnityPlayer.a((Runnable) new Runnable() {
            public final void run() {
                r.this.b.hideVideoPlayer();
            }
        });
    }

    public final boolean onKeyDown(int i2, KeyEvent keyEvent) {
        if (i2 != 4 && (this.g != 2 || i2 == 0 || keyEvent.isSystem())) {
            return this.t != null ? this.t.onKeyDown(i2, keyEvent) : super.onKeyDown(i2, keyEvent);
        }
        onDestroy();
        return true;
    }

    /* access modifiers changed from: protected */
    public final void onPause() {
        if (a) {
            a("onPause called");
        }
        this.m.unregisterListener(this);
        if (!this.x) {
            pause();
            this.x = false;
        }
        if (this.s != null) {
            this.y = this.s.getCurrentPosition();
        }
        this.z = false;
    }

    public final void onPrepared(MediaPlayer mediaPlayer) {
        if (a) {
            a("onPrepared called");
        }
        this.v = true;
        if (this.v && this.u) {
            b();
        }
    }

    /* access modifiers changed from: protected */
    public final void onResume() {
        if (a) {
            a("onResume called");
        }
        if (!this.z) {
            this.m.registerListener(this, this.m.getDefaultSensor(1), 1);
            if (!this.x) {
                start();
            }
        }
        this.z = true;
    }

    public final void onSensorChanged(SensorEvent sensorEvent) {
        if (sensorEvent.sensor.getType() == 1) {
            this.b.nativeDeviceOrientation(calculateDeviceOrientation(sensorEvent, this.n));
        }
    }

    public final boolean onTouchEvent(MotionEvent motionEvent) {
        int action = motionEvent.getAction() & 255;
        if (this.g != 2 || action != 0) {
            return this.t != null ? this.t.onTouchEvent(motionEvent) : super.onTouchEvent(motionEvent);
        }
        onDestroy();
        return true;
    }

    public final void onVideoSizeChanged(MediaPlayer mediaPlayer, int i2, int i3) {
        if (a) {
            a("onVideoSizeChanged called " + i2 + "x" + i3);
        }
        if (i2 != 0 && i3 != 0) {
            this.u = true;
            this.q = i2;
            this.r = i3;
            if (this.v && this.u) {
                b();
            }
        } else if (a) {
            a("invalid video width(" + i2 + ") or height(" + i3 + ")");
        }
    }

    public final void pause() {
        if (this.s != null) {
            this.s.pause();
            this.x = true;
        }
    }

    public final void seekTo(int i2) {
        if (this.s != null) {
            this.s.seekTo(i2);
        }
    }

    public final void start() {
        if (this.s != null) {
            this.s.start();
            this.x = false;
        }
    }

    public final void surfaceChanged(SurfaceHolder surfaceHolder, int i2, int i3, int i4) {
        if (a) {
            a("surfaceChanged called " + i2 + " " + i3 + "x" + i4);
        }
        this.o = i3;
        this.p = i4;
    }

    public final void surfaceCreated(SurfaceHolder surfaceHolder) {
        if (a) {
            a("surfaceCreated called");
        }
        a();
        seekTo(this.y);
    }

    public final void surfaceDestroyed(SurfaceHolder surfaceHolder) {
        if (a) {
            a("surfaceDestroyed called");
        }
        doCleanUp();
    }

    /* access modifiers changed from: protected */
    public final void updateVideoLayout() {
        if (a) {
            a("updateVideoLayout");
        }
        WindowManager windowManager = (WindowManager) this.c.getSystemService("window");
        this.o = windowManager.getDefaultDisplay().getWidth();
        this.p = windowManager.getDefaultDisplay().getHeight();
        int i2 = this.o;
        int i3 = this.p;
        if (this.h == 1 || this.h == 2) {
            float f2 = ((float) this.q) / ((float) this.r);
            if (((float) this.o) / ((float) this.p) <= f2) {
                i3 = (int) (((float) this.o) / f2);
            } else {
                i2 = (int) (((float) this.p) * f2);
            }
        } else if (this.h == 0) {
            i2 = this.q;
            i3 = this.r;
        }
        if (a) {
            a("frameWidth = " + i2 + "; frameHeight = " + i3);
        }
        this.l.updateViewLayout(this.d, new FrameLayout.LayoutParams(i2, i3, 17));
    }
}
