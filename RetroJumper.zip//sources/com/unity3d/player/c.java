package com.unity3d.player;

import android.app.Activity;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

abstract class c implements SurfaceHolder.Callback {
    private final Activity a = ((Activity) o.a.a());
    /* access modifiers changed from: private */
    public final int b = 3;
    /* access modifiers changed from: private */
    public SurfaceView c;

    c(int i) {
    }

    /* access modifiers changed from: package-private */
    public final void a() {
        this.a.runOnUiThread(new Runnable() {
            public final void run() {
                if (c.this.c == null) {
                    SurfaceView unused = c.this.c = new SurfaceView(o.a.a());
                    c.this.c.getHolder().setType(c.this.b);
                    c.this.c.getHolder().addCallback(c.this);
                    o.a.a(c.this.c);
                    c.this.c.setVisibility(0);
                }
            }
        });
    }

    /* access modifiers changed from: package-private */
    public final void b() {
        this.a.runOnUiThread(new Runnable() {
            public final void run() {
                if (c.this.c != null) {
                    o.a.b(c.this.c);
                }
                SurfaceView unused = c.this.c = null;
            }
        });
    }

    public void surfaceChanged(SurfaceHolder surfaceHolder, int i, int i2, int i3) {
    }

    public void surfaceDestroyed(SurfaceHolder surfaceHolder) {
    }
}
