package com.unity3d.player;

import android.os.Build;

public final class l {
    static final boolean a = (Build.VERSION.SDK_INT >= 11);
    static final boolean b;
    static final g c = (a ? new e() : null);
    static final f d;

    static {
        d dVar = null;
        boolean z = true;
        if (Build.VERSION.SDK_INT < 12) {
            z = false;
        }
        b = z;
        if (b) {
            dVar = new d();
        }
        d = dVar;
    }
}
