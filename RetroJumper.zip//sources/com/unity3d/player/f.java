package com.unity3d.player;

import android.view.MotionEvent;
import android.view.View;

public interface f {
    boolean a(View view, MotionEvent motionEvent);
}
