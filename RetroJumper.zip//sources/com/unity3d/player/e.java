package com.unity3d.player;

import android.graphics.SurfaceTexture;
import android.hardware.Camera;
import android.os.Handler;
import android.view.View;

public final class e implements g {
    private static final SurfaceTexture a = new SurfaceTexture(-1);
    /* access modifiers changed from: private */
    public volatile boolean b;

    /* access modifiers changed from: private */
    public void a(final View view, int i) {
        Handler handler = view.getHandler();
        if (handler == null) {
            a(view, this.b);
        } else {
            handler.postDelayed(new Runnable() {
                public final void run() {
                    e.this.a(view, e.this.b);
                }
            }, (long) i);
        }
    }

    public final void a(final View view) {
        view.setOnSystemUiVisibilityChangeListener(new View.OnSystemUiVisibilityChangeListener() {
            public final void onSystemUiVisibilityChange(int i) {
                e.this.a(view, 1000);
            }
        });
    }

    public final void a(View view, boolean z) {
        this.b = z;
        view.setSystemUiVisibility(this.b ? view.getSystemUiVisibility() | 1 : view.getSystemUiVisibility() & -2);
    }

    public final boolean a() {
        return this.b;
    }

    public final boolean a(Camera camera) {
        try {
            camera.setPreviewTexture(a);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public final void b(View view) {
        if (this.b) {
            a(view, false);
            this.b = true;
            a(view, 500);
        }
    }
}
