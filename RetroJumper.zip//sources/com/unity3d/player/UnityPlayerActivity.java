package com.unity3d.player;

public class UnityPlayerActivity extends UnityPlayerNativeActivity {
}
