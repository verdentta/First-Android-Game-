package com.unity3d.player;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import com.google.android.gms.cast.Cast;

public class UnityPlayerProxyActivity extends Activity {
    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        Intent intent = new Intent(this, UnityPlayerNativeActivity.class);
        intent.addFlags(Cast.MAX_MESSAGE_LENGTH);
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            intent.putExtras(extras);
        }
        startActivity(intent);
    }
}
