package com.unity3d.player;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import com.google.android.gms.cast.Cast;
import java.io.File;

public class PsmMainActivity extends Activity {
    private static void a(File file) {
        if (file.isDirectory()) {
            for (File a : file.listFiles()) {
                a(a);
            }
        }
        file.delete();
        Log.d(PsmMainActivity.class.getSimpleName(), "deleted : " + file.getAbsolutePath());
    }

    /* access modifiers changed from: protected */
    public void DecompressAPK(File file) {
        new b(this).execute(new File[]{file, getFilesDir(), getFilesDir()});
    }

    /* access modifiers changed from: protected */
    public void LaunchApp() {
        Intent intent = new Intent(this, PsmUnityActivity.class);
        intent.addFlags(Cast.MAX_MESSAGE_LENGTH);
        Bundle bundle = new Bundle();
        bundle.putString("path", getFilesDir().getPath());
        intent.putExtras(bundle);
        startActivity(intent);
        finish();
    }

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        for (File a : getFilesDir().listFiles()) {
            a(a);
        }
        DecompressAPK(new File(super.getPackageCodePath()));
    }
}
