package com.unity3d.player;

import android.hardware.Camera;
import android.view.View;

public interface g {
    void a(View view);

    void a(View view, boolean z);

    boolean a();

    boolean a(Camera camera);

    void b(View view);
}
