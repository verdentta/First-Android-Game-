package com.google.android.gms.drive.internal;

import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.a;
import com.google.android.gms.drive.Drive;

abstract class q<R extends Result> extends a.b<R, r> {
    public q() {
        super(Drive.yH);
    }
}
