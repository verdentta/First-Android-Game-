package com.google.android.gms.drive.metadata;

public interface SearchableOrderedMetadataField<T> extends SearchableMetadataField<T> {
}
