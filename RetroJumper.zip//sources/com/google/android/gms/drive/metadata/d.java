package com.google.android.gms.drive.metadata;

import java.lang.Comparable;

public abstract class d<T extends Comparable<T>> extends a<T> {
    protected d(String str, int i) {
        super(str, i);
    }
}
