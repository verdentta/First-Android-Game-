package com.google.android.gms.internal;

public interface ad {
    void a(ac acVar);
}
