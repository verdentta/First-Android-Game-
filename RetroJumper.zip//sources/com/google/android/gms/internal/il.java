package com.google.android.gms.internal;

public final class il implements ij {
    private static il Hv;

    public static synchronized ij gb() {
        il ilVar;
        synchronized (il.class) {
            if (Hv == null) {
                Hv = new il();
            }
            ilVar = Hv;
        }
        return ilVar;
    }

    public long currentTimeMillis() {
        return System.currentTimeMillis();
    }
}
