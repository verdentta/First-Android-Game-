package com.google.android.gms.internal;

import java.util.Map;

public interface bc {
    void b(ex exVar, Map<String, String> map);
}
