package com.google.android.gms.internal;

import android.location.Location;

public final class bj implements bi {
    public Location a(long j) {
        return null;
    }

    public void init() {
    }
}
