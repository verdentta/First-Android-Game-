package com.google.android.gms.internal;

import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import java.util.ArrayList;
import java.util.HashMap;

public abstract class hy {

    public static class a<I, O> implements SafeParcelable {
        public static final hz CREATOR = new hz();
        protected final int Hb;
        protected final boolean Hc;
        protected final int Hd;
        protected final boolean He;
        protected final String Hf;
        protected final int Hg;
        protected final Class<? extends hy> Hh;
        protected final String Hi;
        private ib Hj;
        /* access modifiers changed from: private */
        public b<I, O> Hk;
        private final int xM;

        a(int i, int i2, boolean z, int i3, boolean z2, String str, int i4, String str2, ht htVar) {
            this.xM = i;
            this.Hb = i2;
            this.Hc = z;
            this.Hd = i3;
            this.He = z2;
            this.Hf = str;
            this.Hg = i4;
            if (str2 == null) {
                this.Hh = null;
                this.Hi = null;
            } else {
                this.Hh = ie.class;
                this.Hi = str2;
            }
            if (htVar == null) {
                this.Hk = null;
            } else {
                this.Hk = htVar.fC();
            }
        }

        protected a(int i, boolean z, int i2, boolean z2, String str, int i3, Class<? extends hy> cls, b<I, O> bVar) {
            this.xM = 1;
            this.Hb = i;
            this.Hc = z;
            this.Hd = i2;
            this.He = z2;
            this.Hf = str;
            this.Hg = i3;
            this.Hh = cls;
            if (cls == null) {
                this.Hi = null;
            } else {
                this.Hi = cls.getCanonicalName();
            }
            this.Hk = bVar;
        }

        public static a a(String str, int i, b<?, ?> bVar, boolean z) {
            return new a(bVar.fE(), z, bVar.fF(), false, str, i, (Class<? extends hy>) null, bVar);
        }

        public static <T extends hy> a<T, T> a(String str, int i, Class<T> cls) {
            return new a<>(11, false, 11, false, str, i, cls, (b) null);
        }

        public static <T extends hy> a<ArrayList<T>, ArrayList<T>> b(String str, int i, Class<T> cls) {
            return new a<>(11, true, 11, true, str, i, cls, (b) null);
        }

        public static a<Integer, Integer> g(String str, int i) {
            return new a<>(0, false, 0, false, str, i, (Class<? extends hy>) null, (b) null);
        }

        public static a<Double, Double> h(String str, int i) {
            return new a<>(4, false, 4, false, str, i, (Class<? extends hy>) null, (b) null);
        }

        public static a<Boolean, Boolean> i(String str, int i) {
            return new a<>(6, false, 6, false, str, i, (Class<? extends hy>) null, (b) null);
        }

        public static a<String, String> j(String str, int i) {
            return new a<>(7, false, 7, false, str, i, (Class<? extends hy>) null, (b) null);
        }

        public static a<ArrayList<String>, ArrayList<String>> k(String str, int i) {
            return new a<>(7, true, 7, true, str, i, (Class<? extends hy>) null, (b) null);
        }

        public void a(ib ibVar) {
            this.Hj = ibVar;
        }

        public int describeContents() {
            hz hzVar = CREATOR;
            return 0;
        }

        public int fE() {
            return this.Hb;
        }

        public int fF() {
            return this.Hd;
        }

        public a<I, O> fJ() {
            return new a<>(this.xM, this.Hb, this.Hc, this.Hd, this.He, this.Hf, this.Hg, this.Hi, fR());
        }

        public boolean fK() {
            return this.Hc;
        }

        public boolean fL() {
            return this.He;
        }

        public String fM() {
            return this.Hf;
        }

        public int fN() {
            return this.Hg;
        }

        public Class<? extends hy> fO() {
            return this.Hh;
        }

        /* access modifiers changed from: package-private */
        public String fP() {
            if (this.Hi == null) {
                return null;
            }
            return this.Hi;
        }

        public boolean fQ() {
            return this.Hk != null;
        }

        /* access modifiers changed from: package-private */
        public ht fR() {
            if (this.Hk == null) {
                return null;
            }
            return ht.a(this.Hk);
        }

        public HashMap<String, a<?, ?>> fS() {
            hm.f(this.Hi);
            hm.f(this.Hj);
            return this.Hj.aJ(this.Hi);
        }

        public I g(O o) {
            return this.Hk.g(o);
        }

        public int getVersionCode() {
            return this.xM;
        }

        public String toString() {
            StringBuilder sb = new StringBuilder();
            sb.append("Field\n");
            sb.append("            versionCode=").append(this.xM).append(10);
            sb.append("                 typeIn=").append(this.Hb).append(10);
            sb.append("            typeInArray=").append(this.Hc).append(10);
            sb.append("                typeOut=").append(this.Hd).append(10);
            sb.append("           typeOutArray=").append(this.He).append(10);
            sb.append("        outputFieldName=").append(this.Hf).append(10);
            sb.append("      safeParcelFieldId=").append(this.Hg).append(10);
            sb.append("       concreteTypeName=").append(fP()).append(10);
            if (fO() != null) {
                sb.append("     concreteType.class=").append(fO().getCanonicalName()).append(10);
            }
            sb.append("          converterName=").append(this.Hk == null ? "null" : this.Hk.getClass().getCanonicalName()).append(10);
            return sb.toString();
        }

        public void writeToParcel(Parcel out, int flags) {
            hz hzVar = CREATOR;
            hz.a(this, out, flags);
        }
    }

    public interface b<I, O> {
        int fE();

        int fF();

        I g(O o);
    }

    private void a(StringBuilder sb, a aVar, Object obj) {
        if (aVar.fE() == 11) {
            sb.append(((hy) aVar.fO().cast(obj)).toString());
        } else if (aVar.fE() == 7) {
            sb.append("\"");
            sb.append(in.aK((String) obj));
            sb.append("\"");
        } else {
            sb.append(obj);
        }
    }

    private void a(StringBuilder sb, a aVar, ArrayList<Object> arrayList) {
        sb.append("[");
        int size = arrayList.size();
        for (int i = 0; i < size; i++) {
            if (i > 0) {
                sb.append(",");
            }
            Object obj = arrayList.get(i);
            if (obj != null) {
                a(sb, aVar, obj);
            }
        }
        sb.append("]");
    }

    /* access modifiers changed from: protected */
    public <O, I> I a(a<I, O> aVar, Object obj) {
        return aVar.Hk != null ? aVar.g(obj) : obj;
    }

    /* access modifiers changed from: protected */
    public boolean a(a aVar) {
        return aVar.fF() == 11 ? aVar.fL() ? aI(aVar.fM()) : aH(aVar.fM()) : aG(aVar.fM());
    }

    /* access modifiers changed from: protected */
    public abstract Object aF(String str);

    /* access modifiers changed from: protected */
    public abstract boolean aG(String str);

    /* access modifiers changed from: protected */
    public boolean aH(String str) {
        throw new UnsupportedOperationException("Concrete types not supported");
    }

    /* access modifiers changed from: protected */
    public boolean aI(String str) {
        throw new UnsupportedOperationException("Concrete type arrays not supported");
    }

    /* access modifiers changed from: protected */
    public Object b(a aVar) {
        String fM = aVar.fM();
        if (aVar.fO() == null) {
            return aF(aVar.fM());
        }
        hm.a(aF(aVar.fM()) == null, "Concrete field shouldn't be value object: %s", aVar.fM());
        HashMap<String, Object> fI = aVar.fL() ? fI() : fH();
        if (fI != null) {
            return fI.get(fM);
        }
        try {
            return getClass().getMethod("get" + Character.toUpperCase(fM.charAt(0)) + fM.substring(1), new Class[0]).invoke(this, new Object[0]);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public abstract HashMap<String, a<?, ?>> fG();

    public HashMap<String, Object> fH() {
        return null;
    }

    public HashMap<String, Object> fI() {
        return null;
    }

    public String toString() {
        HashMap<String, a<?, ?>> fG = fG();
        StringBuilder sb = new StringBuilder(100);
        for (String next : fG.keySet()) {
            a aVar = fG.get(next);
            if (a(aVar)) {
                Object a2 = a(aVar, b(aVar));
                if (sb.length() == 0) {
                    sb.append("{");
                } else {
                    sb.append(",");
                }
                sb.append("\"").append(next).append("\":");
                if (a2 != null) {
                    switch (aVar.fF()) {
                        case 8:
                            sb.append("\"").append(ih.d((byte[]) a2)).append("\"");
                            break;
                        case 9:
                            sb.append("\"").append(ih.e((byte[]) a2)).append("\"");
                            break;
                        case 10:
                            io.a(sb, (HashMap) a2);
                            break;
                        default:
                            if (!aVar.fK()) {
                                a(sb, aVar, a2);
                                break;
                            } else {
                                a(sb, aVar, (ArrayList<Object>) (ArrayList) a2);
                                break;
                            }
                    }
                } else {
                    sb.append("null");
                }
            }
        }
        if (sb.length() > 0) {
            sb.append("}");
        } else {
            sb.append("{}");
        }
        return sb.toString();
    }
}
