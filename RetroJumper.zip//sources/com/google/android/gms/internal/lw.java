package com.google.android.gms.internal;

import com.google.ads.AdSize;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import java.io.IOException;
import java.util.Arrays;

public final class lw extends ma<lw> {
    public a[] amr;

    public static final class a extends ma<a> {
        private static volatile a[] ams;
        public C0075a amt;
        public String name;

        /* renamed from: com.google.android.gms.internal.lw$a$a  reason: collision with other inner class name */
        public static final class C0075a extends ma<C0075a> {
            private static volatile C0075a[] amu;
            public C0076a amv;
            public int type;

            /* renamed from: com.google.android.gms.internal.lw$a$a$a  reason: collision with other inner class name */
            public static final class C0076a extends ma<C0076a> {
                public long amA;
                public int amB;
                public int amC;
                public boolean amD;
                public a[] amE;
                public C0075a[] amF;
                public String[] amG;
                public long[] amH;
                public float[] amI;
                public long amJ;
                public byte[] amw;
                public String amx;
                public double amy;
                public float amz;

                public C0076a() {
                    nA();
                }

                public void a(lz lzVar) throws IOException {
                    if (!Arrays.equals(this.amw, mh.ank)) {
                        lzVar.a(1, this.amw);
                    }
                    if (!this.amx.equals("")) {
                        lzVar.b(2, this.amx);
                    }
                    if (Double.doubleToLongBits(this.amy) != Double.doubleToLongBits(0.0d)) {
                        lzVar.a(3, this.amy);
                    }
                    if (Float.floatToIntBits(this.amz) != Float.floatToIntBits(BitmapDescriptorFactory.HUE_RED)) {
                        lzVar.b(4, this.amz);
                    }
                    if (this.amA != 0) {
                        lzVar.b(5, this.amA);
                    }
                    if (this.amB != 0) {
                        lzVar.p(6, this.amB);
                    }
                    if (this.amC != 0) {
                        lzVar.q(7, this.amC);
                    }
                    if (this.amD) {
                        lzVar.a(8, this.amD);
                    }
                    if (this.amE != null && this.amE.length > 0) {
                        for (a aVar : this.amE) {
                            if (aVar != null) {
                                lzVar.a(9, (me) aVar);
                            }
                        }
                    }
                    if (this.amF != null && this.amF.length > 0) {
                        for (C0075a aVar2 : this.amF) {
                            if (aVar2 != null) {
                                lzVar.a(10, (me) aVar2);
                            }
                        }
                    }
                    if (this.amG != null && this.amG.length > 0) {
                        for (String str : this.amG) {
                            if (str != null) {
                                lzVar.b(11, str);
                            }
                        }
                    }
                    if (this.amH != null && this.amH.length > 0) {
                        for (long b : this.amH) {
                            lzVar.b(12, b);
                        }
                    }
                    if (this.amJ != 0) {
                        lzVar.b(13, this.amJ);
                    }
                    if (this.amI != null && this.amI.length > 0) {
                        for (float b2 : this.amI) {
                            lzVar.b(14, b2);
                        }
                    }
                    super.a(lzVar);
                }

                /* access modifiers changed from: protected */
                public int c() {
                    int c = super.c();
                    if (!Arrays.equals(this.amw, mh.ank)) {
                        c += lz.b(1, this.amw);
                    }
                    if (!this.amx.equals("")) {
                        c += lz.h(2, this.amx);
                    }
                    if (Double.doubleToLongBits(this.amy) != Double.doubleToLongBits(0.0d)) {
                        c += lz.b(3, this.amy);
                    }
                    if (Float.floatToIntBits(this.amz) != Float.floatToIntBits(BitmapDescriptorFactory.HUE_RED)) {
                        c += lz.c(4, this.amz);
                    }
                    if (this.amA != 0) {
                        c += lz.d(5, this.amA);
                    }
                    if (this.amB != 0) {
                        c += lz.r(6, this.amB);
                    }
                    if (this.amC != 0) {
                        c += lz.s(7, this.amC);
                    }
                    if (this.amD) {
                        c += lz.b(8, this.amD);
                    }
                    if (this.amE != null && this.amE.length > 0) {
                        int i = c;
                        for (a aVar : this.amE) {
                            if (aVar != null) {
                                i += lz.b(9, (me) aVar);
                            }
                        }
                        c = i;
                    }
                    if (this.amF != null && this.amF.length > 0) {
                        int i2 = c;
                        for (C0075a aVar2 : this.amF) {
                            if (aVar2 != null) {
                                i2 += lz.b(10, (me) aVar2);
                            }
                        }
                        c = i2;
                    }
                    if (this.amG != null && this.amG.length > 0) {
                        int i3 = 0;
                        int i4 = 0;
                        for (String str : this.amG) {
                            if (str != null) {
                                i4++;
                                i3 += lz.cz(str);
                            }
                        }
                        c = c + i3 + (i4 * 1);
                    }
                    if (this.amH != null && this.amH.length > 0) {
                        int i5 = 0;
                        for (long D : this.amH) {
                            i5 += lz.D(D);
                        }
                        c = c + i5 + (this.amH.length * 1);
                    }
                    if (this.amJ != 0) {
                        c += lz.d(13, this.amJ);
                    }
                    return (this.amI == null || this.amI.length <= 0) ? c : c + (this.amI.length * 4) + (this.amI.length * 1);
                }

                public boolean equals(Object o) {
                    if (o == this) {
                        return true;
                    }
                    if (!(o instanceof C0076a)) {
                        return false;
                    }
                    C0076a aVar = (C0076a) o;
                    if (!Arrays.equals(this.amw, aVar.amw)) {
                        return false;
                    }
                    if (this.amx == null) {
                        if (aVar.amx != null) {
                            return false;
                        }
                    } else if (!this.amx.equals(aVar.amx)) {
                        return false;
                    }
                    if (Double.doubleToLongBits(this.amy) != Double.doubleToLongBits(aVar.amy) || Float.floatToIntBits(this.amz) != Float.floatToIntBits(aVar.amz) || this.amA != aVar.amA || this.amB != aVar.amB || this.amC != aVar.amC || this.amD != aVar.amD || !mc.equals((Object[]) this.amE, (Object[]) aVar.amE) || !mc.equals((Object[]) this.amF, (Object[]) aVar.amF) || !mc.equals((Object[]) this.amG, (Object[]) aVar.amG) || !mc.equals(this.amH, aVar.amH) || !mc.equals(this.amI, aVar.amI) || this.amJ != aVar.amJ) {
                        return false;
                    }
                    if (this.amX == null || this.amX.isEmpty()) {
                        return aVar.amX == null || aVar.amX.isEmpty();
                    }
                    return this.amX.equals(aVar.amX);
                }

                public int hashCode() {
                    int i = 0;
                    int hashCode = (this.amx == null ? 0 : this.amx.hashCode()) + ((Arrays.hashCode(this.amw) + 527) * 31);
                    long doubleToLongBits = Double.doubleToLongBits(this.amy);
                    int floatToIntBits = ((((((((((((((this.amD ? 1231 : 1237) + (((((((((((hashCode * 31) + ((int) (doubleToLongBits ^ (doubleToLongBits >>> 32)))) * 31) + Float.floatToIntBits(this.amz)) * 31) + ((int) (this.amA ^ (this.amA >>> 32)))) * 31) + this.amB) * 31) + this.amC) * 31)) * 31) + mc.hashCode((Object[]) this.amE)) * 31) + mc.hashCode((Object[]) this.amF)) * 31) + mc.hashCode((Object[]) this.amG)) * 31) + mc.hashCode(this.amH)) * 31) + mc.hashCode(this.amI)) * 31) + ((int) (this.amJ ^ (this.amJ >>> 32)))) * 31;
                    if (this.amX != null && !this.amX.isEmpty()) {
                        i = this.amX.hashCode();
                    }
                    return floatToIntBits + i;
                }

                public C0076a nA() {
                    this.amw = mh.ank;
                    this.amx = "";
                    this.amy = 0.0d;
                    this.amz = BitmapDescriptorFactory.HUE_RED;
                    this.amA = 0;
                    this.amB = 0;
                    this.amC = 0;
                    this.amD = false;
                    this.amE = a.nw();
                    this.amF = C0075a.ny();
                    this.amG = mh.ani;
                    this.amH = mh.ane;
                    this.amI = mh.anf;
                    this.amJ = 0;
                    this.amX = null;
                    this.anb = -1;
                    return this;
                }

                /* renamed from: t */
                public C0076a b(ly lyVar) throws IOException {
                    while (true) {
                        int nB = lyVar.nB();
                        switch (nB) {
                            case 0:
                                break;
                            case 10:
                                this.amw = lyVar.readBytes();
                                continue;
                            case 18:
                                this.amx = lyVar.readString();
                                continue;
                            case 25:
                                this.amy = lyVar.readDouble();
                                continue;
                            case 37:
                                this.amz = lyVar.readFloat();
                                continue;
                            case 40:
                                this.amA = lyVar.nD();
                                continue;
                            case 48:
                                this.amB = lyVar.nE();
                                continue;
                            case 56:
                                this.amC = lyVar.nG();
                                continue;
                            case 64:
                                this.amD = lyVar.nF();
                                continue;
                            case 74:
                                int b = mh.b(lyVar, 74);
                                int length = this.amE == null ? 0 : this.amE.length;
                                a[] aVarArr = new a[(b + length)];
                                if (length != 0) {
                                    System.arraycopy(this.amE, 0, aVarArr, 0, length);
                                }
                                while (length < aVarArr.length - 1) {
                                    aVarArr[length] = new a();
                                    lyVar.a(aVarArr[length]);
                                    lyVar.nB();
                                    length++;
                                }
                                aVarArr[length] = new a();
                                lyVar.a(aVarArr[length]);
                                this.amE = aVarArr;
                                continue;
                            case 82:
                                int b2 = mh.b(lyVar, 82);
                                int length2 = this.amF == null ? 0 : this.amF.length;
                                C0075a[] aVarArr2 = new C0075a[(b2 + length2)];
                                if (length2 != 0) {
                                    System.arraycopy(this.amF, 0, aVarArr2, 0, length2);
                                }
                                while (length2 < aVarArr2.length - 1) {
                                    aVarArr2[length2] = new C0075a();
                                    lyVar.a(aVarArr2[length2]);
                                    lyVar.nB();
                                    length2++;
                                }
                                aVarArr2[length2] = new C0075a();
                                lyVar.a(aVarArr2[length2]);
                                this.amF = aVarArr2;
                                continue;
                            case AdSize.LARGE_AD_HEIGHT:
                                int b3 = mh.b(lyVar, 90);
                                int length3 = this.amG == null ? 0 : this.amG.length;
                                String[] strArr = new String[(b3 + length3)];
                                if (length3 != 0) {
                                    System.arraycopy(this.amG, 0, strArr, 0, length3);
                                }
                                while (length3 < strArr.length - 1) {
                                    strArr[length3] = lyVar.readString();
                                    lyVar.nB();
                                    length3++;
                                }
                                strArr[length3] = lyVar.readString();
                                this.amG = strArr;
                                continue;
                            case 96:
                                int b4 = mh.b(lyVar, 96);
                                int length4 = this.amH == null ? 0 : this.amH.length;
                                long[] jArr = new long[(b4 + length4)];
                                if (length4 != 0) {
                                    System.arraycopy(this.amH, 0, jArr, 0, length4);
                                }
                                while (length4 < jArr.length - 1) {
                                    jArr[length4] = lyVar.nD();
                                    lyVar.nB();
                                    length4++;
                                }
                                jArr[length4] = lyVar.nD();
                                this.amH = jArr;
                                continue;
                            case 98:
                                int ex = lyVar.ex(lyVar.nI());
                                int position = lyVar.getPosition();
                                int i = 0;
                                while (lyVar.nN() > 0) {
                                    lyVar.nD();
                                    i++;
                                }
                                lyVar.ez(position);
                                int length5 = this.amH == null ? 0 : this.amH.length;
                                long[] jArr2 = new long[(i + length5)];
                                if (length5 != 0) {
                                    System.arraycopy(this.amH, 0, jArr2, 0, length5);
                                }
                                while (length5 < jArr2.length) {
                                    jArr2[length5] = lyVar.nD();
                                    length5++;
                                }
                                this.amH = jArr2;
                                lyVar.ey(ex);
                                continue;
                            case LocationRequest.PRIORITY_LOW_POWER /*104*/:
                                this.amJ = lyVar.nD();
                                continue;
                            case 114:
                                int nI = lyVar.nI();
                                int ex2 = lyVar.ex(nI);
                                int i2 = nI / 4;
                                int length6 = this.amI == null ? 0 : this.amI.length;
                                float[] fArr = new float[(i2 + length6)];
                                if (length6 != 0) {
                                    System.arraycopy(this.amI, 0, fArr, 0, length6);
                                }
                                while (length6 < fArr.length) {
                                    fArr[length6] = lyVar.readFloat();
                                    length6++;
                                }
                                this.amI = fArr;
                                lyVar.ey(ex2);
                                continue;
                            case 117:
                                int b5 = mh.b(lyVar, 117);
                                int length7 = this.amI == null ? 0 : this.amI.length;
                                float[] fArr2 = new float[(b5 + length7)];
                                if (length7 != 0) {
                                    System.arraycopy(this.amI, 0, fArr2, 0, length7);
                                }
                                while (length7 < fArr2.length - 1) {
                                    fArr2[length7] = lyVar.readFloat();
                                    lyVar.nB();
                                    length7++;
                                }
                                fArr2[length7] = lyVar.readFloat();
                                this.amI = fArr2;
                                continue;
                            default:
                                if (!a(lyVar, nB)) {
                                    break;
                                } else {
                                    continue;
                                }
                        }
                    }
                    return this;
                }
            }

            public C0075a() {
                nz();
            }

            public static C0075a[] ny() {
                if (amu == null) {
                    synchronized (mc.ana) {
                        if (amu == null) {
                            amu = new C0075a[0];
                        }
                    }
                }
                return amu;
            }

            public void a(lz lzVar) throws IOException {
                lzVar.p(1, this.type);
                if (this.amv != null) {
                    lzVar.a(2, (me) this.amv);
                }
                super.a(lzVar);
            }

            /* access modifiers changed from: protected */
            public int c() {
                int c = super.c() + lz.r(1, this.type);
                return this.amv != null ? c + lz.b(2, (me) this.amv) : c;
            }

            public boolean equals(Object o) {
                if (o == this) {
                    return true;
                }
                if (!(o instanceof C0075a)) {
                    return false;
                }
                C0075a aVar = (C0075a) o;
                if (this.type != aVar.type) {
                    return false;
                }
                if (this.amv == null) {
                    if (aVar.amv != null) {
                        return false;
                    }
                } else if (!this.amv.equals(aVar.amv)) {
                    return false;
                }
                if (this.amX == null || this.amX.isEmpty()) {
                    return aVar.amX == null || aVar.amX.isEmpty();
                }
                return this.amX.equals(aVar.amX);
            }

            public int hashCode() {
                int i = 0;
                int hashCode = ((this.amv == null ? 0 : this.amv.hashCode()) + ((this.type + 527) * 31)) * 31;
                if (this.amX != null && !this.amX.isEmpty()) {
                    i = this.amX.hashCode();
                }
                return hashCode + i;
            }

            public C0075a nz() {
                this.type = 1;
                this.amv = null;
                this.amX = null;
                this.anb = -1;
                return this;
            }

            /* renamed from: s */
            public C0075a b(ly lyVar) throws IOException {
                while (true) {
                    int nB = lyVar.nB();
                    switch (nB) {
                        case 0:
                            break;
                        case 8:
                            int nE = lyVar.nE();
                            switch (nE) {
                                case 1:
                                case 2:
                                case 3:
                                case 4:
                                case 5:
                                case 6:
                                case 7:
                                case 8:
                                case 9:
                                case 10:
                                case 11:
                                case 12:
                                case 13:
                                case 14:
                                case 15:
                                    this.type = nE;
                                    break;
                                default:
                                    continue;
                            }
                        case 18:
                            if (this.amv == null) {
                                this.amv = new C0076a();
                            }
                            lyVar.a(this.amv);
                            continue;
                        default:
                            if (!a(lyVar, nB)) {
                                break;
                            } else {
                                continue;
                            }
                    }
                }
                return this;
            }
        }

        public a() {
            nx();
        }

        public static a[] nw() {
            if (ams == null) {
                synchronized (mc.ana) {
                    if (ams == null) {
                        ams = new a[0];
                    }
                }
            }
            return ams;
        }

        public void a(lz lzVar) throws IOException {
            lzVar.b(1, this.name);
            if (this.amt != null) {
                lzVar.a(2, (me) this.amt);
            }
            super.a(lzVar);
        }

        /* access modifiers changed from: protected */
        public int c() {
            int c = super.c() + lz.h(1, this.name);
            return this.amt != null ? c + lz.b(2, (me) this.amt) : c;
        }

        public boolean equals(Object o) {
            if (o == this) {
                return true;
            }
            if (!(o instanceof a)) {
                return false;
            }
            a aVar = (a) o;
            if (this.name == null) {
                if (aVar.name != null) {
                    return false;
                }
            } else if (!this.name.equals(aVar.name)) {
                return false;
            }
            if (this.amt == null) {
                if (aVar.amt != null) {
                    return false;
                }
            } else if (!this.amt.equals(aVar.amt)) {
                return false;
            }
            if (this.amX == null || this.amX.isEmpty()) {
                return aVar.amX == null || aVar.amX.isEmpty();
            }
            return this.amX.equals(aVar.amX);
        }

        public int hashCode() {
            int i = 0;
            int hashCode = ((this.amt == null ? 0 : this.amt.hashCode()) + (((this.name == null ? 0 : this.name.hashCode()) + 527) * 31)) * 31;
            if (this.amX != null && !this.amX.isEmpty()) {
                i = this.amX.hashCode();
            }
            return hashCode + i;
        }

        public a nx() {
            this.name = "";
            this.amt = null;
            this.amX = null;
            this.anb = -1;
            return this;
        }

        /* renamed from: r */
        public a b(ly lyVar) throws IOException {
            while (true) {
                int nB = lyVar.nB();
                switch (nB) {
                    case 0:
                        break;
                    case 10:
                        this.name = lyVar.readString();
                        continue;
                    case 18:
                        if (this.amt == null) {
                            this.amt = new C0075a();
                        }
                        lyVar.a(this.amt);
                        continue;
                    default:
                        if (!a(lyVar, nB)) {
                            break;
                        } else {
                            continue;
                        }
                }
            }
            return this;
        }
    }

    public lw() {
        nv();
    }

    public static lw n(byte[] bArr) throws md {
        return (lw) me.a(new lw(), bArr);
    }

    public void a(lz lzVar) throws IOException {
        if (this.amr != null && this.amr.length > 0) {
            for (a aVar : this.amr) {
                if (aVar != null) {
                    lzVar.a(1, (me) aVar);
                }
            }
        }
        super.a(lzVar);
    }

    /* access modifiers changed from: protected */
    public int c() {
        int c = super.c();
        if (this.amr != null && this.amr.length > 0) {
            for (a aVar : this.amr) {
                if (aVar != null) {
                    c += lz.b(1, (me) aVar);
                }
            }
        }
        return c;
    }

    public boolean equals(Object o) {
        if (o == this) {
            return true;
        }
        if (!(o instanceof lw)) {
            return false;
        }
        lw lwVar = (lw) o;
        if (!mc.equals((Object[]) this.amr, (Object[]) lwVar.amr)) {
            return false;
        }
        if (this.amX == null || this.amX.isEmpty()) {
            return lwVar.amX == null || lwVar.amX.isEmpty();
        }
        return this.amX.equals(lwVar.amX);
    }

    public int hashCode() {
        return ((this.amX == null || this.amX.isEmpty()) ? 0 : this.amX.hashCode()) + ((mc.hashCode((Object[]) this.amr) + 527) * 31);
    }

    public lw nv() {
        this.amr = a.nw();
        this.amX = null;
        this.anb = -1;
        return this;
    }

    /* renamed from: q */
    public lw b(ly lyVar) throws IOException {
        while (true) {
            int nB = lyVar.nB();
            switch (nB) {
                case 0:
                    break;
                case 10:
                    int b = mh.b(lyVar, 10);
                    int length = this.amr == null ? 0 : this.amr.length;
                    a[] aVarArr = new a[(b + length)];
                    if (length != 0) {
                        System.arraycopy(this.amr, 0, aVarArr, 0, length);
                    }
                    while (length < aVarArr.length - 1) {
                        aVarArr[length] = new a();
                        lyVar.a(aVarArr[length]);
                        lyVar.nB();
                        length++;
                    }
                    aVarArr[length] = new a();
                    lyVar.a(aVarArr[length]);
                    this.amr = aVarArr;
                    continue;
                default:
                    if (!a(lyVar, nB)) {
                        break;
                    } else {
                        continue;
                    }
            }
        }
        return this;
    }
}
