package com.google.android.gms.internal;

import android.os.Build;

public final class ip {
    private static boolean aF(int i) {
        return Build.VERSION.SDK_INT >= i;
    }

    public static boolean gc() {
        return aF(11);
    }

    public static boolean gd() {
        return aF(12);
    }

    public static boolean ge() {
        return aF(13);
    }

    public static boolean gf() {
        return aF(14);
    }

    public static boolean gg() {
        return aF(16);
    }

    public static boolean gh() {
        return aF(17);
    }

    public static boolean gi() {
        return aF(19);
    }
}
