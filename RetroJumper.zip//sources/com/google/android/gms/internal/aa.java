package com.google.android.gms.internal;

import org.json.JSONObject;

public final class aa {
    private final String lo;
    private final JSONObject lp;
    private final String lq;
    private final String lr;

    public aa(String str, ev evVar, String str2, JSONObject jSONObject) {
        this.lr = evVar.sw;
        this.lp = jSONObject;
        this.lq = str;
        this.lo = str2;
    }

    public String ar() {
        return this.lo;
    }

    public String as() {
        return this.lr;
    }

    public JSONObject at() {
        return this.lp;
    }

    public String au() {
        return this.lq;
    }
}
