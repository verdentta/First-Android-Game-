package com.google.android.gms.internal;

import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public abstract class ha implements SafeParcelable {
    private static final Object FX = new Object();
    private static ClassLoader FY = null;
    private static Integer FZ = null;
    private boolean Ga = false;

    private static boolean a(Class<?> cls) {
        try {
            return SafeParcelable.NULL.equals(cls.getField("NULL").get((Object) null));
        } catch (IllegalAccessException | NoSuchFieldException e) {
            return false;
        }
    }

    /* access modifiers changed from: protected */
    public static boolean aA(String str) {
        ClassLoader fp = fp();
        if (fp == null) {
            return true;
        }
        try {
            return a(fp.loadClass(str));
        } catch (Exception e) {
            return false;
        }
    }

    protected static ClassLoader fp() {
        ClassLoader classLoader;
        synchronized (FX) {
            classLoader = FY;
        }
        return classLoader;
    }

    /* access modifiers changed from: protected */
    public static Integer fq() {
        Integer num;
        synchronized (FX) {
            num = FZ;
        }
        return num;
    }

    /* access modifiers changed from: protected */
    public boolean fr() {
        return this.Ga;
    }
}
