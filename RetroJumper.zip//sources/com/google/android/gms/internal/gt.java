package com.google.android.gms.internal;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.SystemClock;

public final class gt extends Drawable implements Drawable.Callback {
    private int FA;
    private int FB;
    private boolean FC;
    private b FD;
    private Drawable FE;
    private Drawable FF;
    private boolean FG;
    private boolean FH;
    private boolean FI;
    private int FJ;
    private boolean Fp;
    private int Fv;
    private long Fw;
    private int Fx;
    private int Fy;
    private int Fz;

    private static final class a extends Drawable {
        /* access modifiers changed from: private */
        public static final a FK = new a();
        private static final C0054a FL = new C0054a();

        /* renamed from: com.google.android.gms.internal.gt$a$a  reason: collision with other inner class name */
        private static final class C0054a extends Drawable.ConstantState {
            private C0054a() {
            }

            public int getChangingConfigurations() {
                return 0;
            }

            public Drawable newDrawable() {
                return a.FK;
            }
        }

        private a() {
        }

        public void draw(Canvas canvas) {
        }

        public Drawable.ConstantState getConstantState() {
            return FL;
        }

        public int getOpacity() {
            return -2;
        }

        public void setAlpha(int alpha) {
        }

        public void setColorFilter(ColorFilter cf) {
        }
    }

    static final class b extends Drawable.ConstantState {
        int FM;
        int FN;

        b(b bVar) {
            if (bVar != null) {
                this.FM = bVar.FM;
                this.FN = bVar.FN;
            }
        }

        public int getChangingConfigurations() {
            return this.FM;
        }

        public Drawable newDrawable() {
            return new gt(this);
        }
    }

    public gt(Drawable drawable, Drawable drawable2) {
        this((b) null);
        drawable = drawable == null ? a.FK : drawable;
        this.FE = drawable;
        drawable.setCallback(this);
        this.FD.FN |= drawable.getChangingConfigurations();
        drawable2 = drawable2 == null ? a.FK : drawable2;
        this.FF = drawable2;
        drawable2.setCallback(this);
        this.FD.FN |= drawable2.getChangingConfigurations();
    }

    gt(b bVar) {
        this.Fv = 0;
        this.Fz = 255;
        this.FB = 0;
        this.Fp = true;
        this.FD = new b(bVar);
    }

    public boolean canConstantState() {
        if (!this.FG) {
            this.FH = (this.FE.getConstantState() == null || this.FF.getConstantState() == null) ? false : true;
            this.FG = true;
        }
        return this.FH;
    }

    public void draw(Canvas canvas) {
        boolean z = true;
        boolean z2 = false;
        switch (this.Fv) {
            case 1:
                this.Fw = SystemClock.uptimeMillis();
                this.Fv = 2;
                break;
            case 2:
                if (this.Fw >= 0) {
                    float uptimeMillis = ((float) (SystemClock.uptimeMillis() - this.Fw)) / ((float) this.FA);
                    if (uptimeMillis < 1.0f) {
                        z = false;
                    }
                    if (z) {
                        this.Fv = 0;
                    }
                    this.FB = (int) ((Math.min(uptimeMillis, 1.0f) * ((float) (this.Fy - this.Fx))) + ((float) this.Fx));
                    break;
                }
                break;
        }
        z2 = z;
        int i = this.FB;
        boolean z3 = this.Fp;
        Drawable drawable = this.FE;
        Drawable drawable2 = this.FF;
        if (z2) {
            if (!z3 || i == 0) {
                drawable.draw(canvas);
            }
            if (i == this.Fz) {
                drawable2.setAlpha(this.Fz);
                drawable2.draw(canvas);
                return;
            }
            return;
        }
        if (z3) {
            drawable.setAlpha(this.Fz - i);
        }
        drawable.draw(canvas);
        if (z3) {
            drawable.setAlpha(this.Fz);
        }
        if (i > 0) {
            drawable2.setAlpha(i);
            drawable2.draw(canvas);
            drawable2.setAlpha(this.Fz);
        }
        invalidateSelf();
    }

    public Drawable fg() {
        return this.FF;
    }

    public int getChangingConfigurations() {
        return super.getChangingConfigurations() | this.FD.FM | this.FD.FN;
    }

    public Drawable.ConstantState getConstantState() {
        if (!canConstantState()) {
            return null;
        }
        this.FD.FM = getChangingConfigurations();
        return this.FD;
    }

    public int getIntrinsicHeight() {
        return Math.max(this.FE.getIntrinsicHeight(), this.FF.getIntrinsicHeight());
    }

    public int getIntrinsicWidth() {
        return Math.max(this.FE.getIntrinsicWidth(), this.FF.getIntrinsicWidth());
    }

    public int getOpacity() {
        if (!this.FI) {
            this.FJ = Drawable.resolveOpacity(this.FE.getOpacity(), this.FF.getOpacity());
            this.FI = true;
        }
        return this.FJ;
    }

    public void invalidateDrawable(Drawable who) {
        Drawable.Callback callback;
        if (ip.gc() && (callback = getCallback()) != null) {
            callback.invalidateDrawable(this);
        }
    }

    public Drawable mutate() {
        if (!this.FC && super.mutate() == this) {
            if (!canConstantState()) {
                throw new IllegalStateException("One or more children of this LayerDrawable does not have constant state; this drawable cannot be mutated.");
            }
            this.FE.mutate();
            this.FF.mutate();
            this.FC = true;
        }
        return this;
    }

    /* access modifiers changed from: protected */
    public void onBoundsChange(Rect bounds) {
        this.FE.setBounds(bounds);
        this.FF.setBounds(bounds);
    }

    public void scheduleDrawable(Drawable who, Runnable what, long when) {
        Drawable.Callback callback;
        if (ip.gc() && (callback = getCallback()) != null) {
            callback.scheduleDrawable(this, what, when);
        }
    }

    public void setAlpha(int alpha) {
        if (this.FB == this.Fz) {
            this.FB = alpha;
        }
        this.Fz = alpha;
        invalidateSelf();
    }

    public void setColorFilter(ColorFilter cf) {
        this.FE.setColorFilter(cf);
        this.FF.setColorFilter(cf);
    }

    public void startTransition(int durationMillis) {
        this.Fx = 0;
        this.Fy = this.Fz;
        this.FB = 0;
        this.FA = durationMillis;
        this.Fv = 1;
        invalidateSelf();
    }

    public void unscheduleDrawable(Drawable who, Runnable what) {
        Drawable.Callback callback;
        if (ip.gc() && (callback = getCallback()) != null) {
            callback.unscheduleDrawable(this, what);
        }
    }
}
