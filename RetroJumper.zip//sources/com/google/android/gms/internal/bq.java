package com.google.android.gms.internal;

public final class bq {
    public final int nL;
    public final bl nM;
    public final bu nN;
    public final String nO;
    public final bo nP;

    public interface a {
        void g(int i);
    }

    public bq(int i) {
        this((bl) null, (bu) null, (String) null, (bo) null, i);
    }

    public bq(bl blVar, bu buVar, String str, bo boVar, int i) {
        this.nM = blVar;
        this.nN = buVar;
        this.nO = str;
        this.nP = boVar;
        this.nL = i;
    }
}
