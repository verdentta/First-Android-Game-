package com.google.android.gms.internal;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Map;

public final class bg implements bc {
    private final bd nd;

    public bg(bd bdVar) {
        this.nd = bdVar;
    }

    private static boolean a(Map<String, String> map) {
        return "1".equals(map.get("custom_close"));
    }

    private static int b(Map<String, String> map) {
        String str = map.get("o");
        if (str != null) {
            if ("p".equalsIgnoreCase(str)) {
                return eo.bS();
            }
            if ("l".equalsIgnoreCase(str)) {
                return eo.bR();
            }
        }
        return -1;
    }

    public void b(ex exVar, Map<String, String> map) {
        String str = map.get("a");
        if (str == null) {
            eu.D("Action missing from an open GMSG.");
            return;
        }
        ey cb = exVar.cb();
        if ("expand".equalsIgnoreCase(str)) {
            if (exVar.ce()) {
                eu.D("Cannot expand WebView that is already expanded.");
            } else {
                cb.a(a(map), b(map));
            }
        } else if ("webapp".equalsIgnoreCase(str)) {
            String str2 = map.get("u");
            if (str2 != null) {
                cb.a(a(map), b(map), str2);
            } else {
                cb.a(a(map), b(map), map.get("html"), map.get("baseurl"));
            }
        } else if ("in_app_purchase".equalsIgnoreCase(str)) {
            String str3 = map.get("product_id");
            String str4 = map.get("report_urls");
            if (this.nd == null) {
                return;
            }
            if (str4 == null || str4.isEmpty()) {
                this.nd.a(str3, new ArrayList());
                return;
            }
            this.nd.a(str3, new ArrayList(Arrays.asList(str4.split(" "))));
        } else {
            cb.a(new ce(map.get("i"), map.get("u"), map.get("m"), map.get("p"), map.get("c"), map.get("f"), map.get("e")));
        }
    }
}
