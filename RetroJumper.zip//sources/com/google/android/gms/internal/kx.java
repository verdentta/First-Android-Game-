package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.b;
import com.google.android.gms.internal.ks;
import java.util.HashSet;
import java.util.Set;

public class kx implements Parcelable.Creator<ks.b.C0068b> {
    static void a(ks.b.C0068b bVar, Parcel parcel, int i) {
        int C = b.C(parcel);
        Set<Integer> kk = bVar.kk();
        if (kk.contains(1)) {
            b.c(parcel, 1, bVar.getVersionCode());
        }
        if (kk.contains(2)) {
            b.c(parcel, 2, bVar.getHeight());
        }
        if (kk.contains(3)) {
            b.a(parcel, 3, bVar.getUrl(), true);
        }
        if (kk.contains(4)) {
            b.c(parcel, 4, bVar.getWidth());
        }
        b.G(parcel, C);
    }

    /* renamed from: bK */
    public ks.b.C0068b createFromParcel(Parcel parcel) {
        int i = 0;
        int B = a.B(parcel);
        HashSet hashSet = new HashSet();
        String str = null;
        int i2 = 0;
        int i3 = 0;
        while (parcel.dataPosition() < B) {
            int A = a.A(parcel);
            switch (a.ar(A)) {
                case 1:
                    i3 = a.g(parcel, A);
                    hashSet.add(1);
                    break;
                case 2:
                    i2 = a.g(parcel, A);
                    hashSet.add(2);
                    break;
                case 3:
                    str = a.o(parcel, A);
                    hashSet.add(3);
                    break;
                case 4:
                    i = a.g(parcel, A);
                    hashSet.add(4);
                    break;
                default:
                    a.b(parcel, A);
                    break;
            }
        }
        if (parcel.dataPosition() == B) {
            return new ks.b.C0068b(hashSet, i3, i2, str, i);
        }
        throw new a.C0010a("Overread allowed size end=" + B, parcel);
    }

    /* renamed from: dh */
    public ks.b.C0068b[] newArray(int i) {
        return new ks.b.C0068b[i];
    }
}
