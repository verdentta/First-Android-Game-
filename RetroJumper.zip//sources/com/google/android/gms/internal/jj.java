package com.google.android.gms.internal;

import android.os.IInterface;

public interface jj<T extends IInterface> {
    void cn();

    T ft();
}
