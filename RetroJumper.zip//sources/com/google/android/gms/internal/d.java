package com.google.android.gms.internal;

import com.google.ads.AdSize;
import java.io.IOException;

public interface d {

    public static final class a extends ma<a> {
        private static volatile a[] fM;
        public String fN;
        public a[] fO;
        public a[] fP;
        public a[] fQ;
        public String fR;
        public String fS;
        public long fT;
        public boolean fU;
        public a[] fV;
        public int[] fW;
        public boolean fX;
        public int type;

        public a() {
            s();
        }

        public static a[] r() {
            if (fM == null) {
                synchronized (mc.ana) {
                    if (fM == null) {
                        fM = new a[0];
                    }
                }
            }
            return fM;
        }

        public void a(lz lzVar) throws IOException {
            lzVar.p(1, this.type);
            if (!this.fN.equals("")) {
                lzVar.b(2, this.fN);
            }
            if (this.fO != null && this.fO.length > 0) {
                for (a aVar : this.fO) {
                    if (aVar != null) {
                        lzVar.a(3, (me) aVar);
                    }
                }
            }
            if (this.fP != null && this.fP.length > 0) {
                for (a aVar2 : this.fP) {
                    if (aVar2 != null) {
                        lzVar.a(4, (me) aVar2);
                    }
                }
            }
            if (this.fQ != null && this.fQ.length > 0) {
                for (a aVar3 : this.fQ) {
                    if (aVar3 != null) {
                        lzVar.a(5, (me) aVar3);
                    }
                }
            }
            if (!this.fR.equals("")) {
                lzVar.b(6, this.fR);
            }
            if (!this.fS.equals("")) {
                lzVar.b(7, this.fS);
            }
            if (this.fT != 0) {
                lzVar.b(8, this.fT);
            }
            if (this.fX) {
                lzVar.a(9, this.fX);
            }
            if (this.fW != null && this.fW.length > 0) {
                for (int p : this.fW) {
                    lzVar.p(10, p);
                }
            }
            if (this.fV != null && this.fV.length > 0) {
                for (a aVar4 : this.fV) {
                    if (aVar4 != null) {
                        lzVar.a(11, (me) aVar4);
                    }
                }
            }
            if (this.fU) {
                lzVar.a(12, this.fU);
            }
            super.a(lzVar);
        }

        /* access modifiers changed from: protected */
        public int c() {
            int c = super.c() + lz.r(1, this.type);
            if (!this.fN.equals("")) {
                c += lz.h(2, this.fN);
            }
            if (this.fO != null && this.fO.length > 0) {
                int i = c;
                for (a aVar : this.fO) {
                    if (aVar != null) {
                        i += lz.b(3, (me) aVar);
                    }
                }
                c = i;
            }
            if (this.fP != null && this.fP.length > 0) {
                int i2 = c;
                for (a aVar2 : this.fP) {
                    if (aVar2 != null) {
                        i2 += lz.b(4, (me) aVar2);
                    }
                }
                c = i2;
            }
            if (this.fQ != null && this.fQ.length > 0) {
                int i3 = c;
                for (a aVar3 : this.fQ) {
                    if (aVar3 != null) {
                        i3 += lz.b(5, (me) aVar3);
                    }
                }
                c = i3;
            }
            if (!this.fR.equals("")) {
                c += lz.h(6, this.fR);
            }
            if (!this.fS.equals("")) {
                c += lz.h(7, this.fS);
            }
            if (this.fT != 0) {
                c += lz.d(8, this.fT);
            }
            if (this.fX) {
                c += lz.b(9, this.fX);
            }
            if (this.fW != null && this.fW.length > 0) {
                int i4 = 0;
                for (int eE : this.fW) {
                    i4 += lz.eE(eE);
                }
                c = c + i4 + (this.fW.length * 1);
            }
            if (this.fV != null && this.fV.length > 0) {
                for (a aVar4 : this.fV) {
                    if (aVar4 != null) {
                        c += lz.b(11, (me) aVar4);
                    }
                }
            }
            return this.fU ? c + lz.b(12, this.fU) : c;
        }

        public boolean equals(Object o) {
            if (o == this) {
                return true;
            }
            if (!(o instanceof a)) {
                return false;
            }
            a aVar = (a) o;
            if (this.type != aVar.type) {
                return false;
            }
            if (this.fN == null) {
                if (aVar.fN != null) {
                    return false;
                }
            } else if (!this.fN.equals(aVar.fN)) {
                return false;
            }
            if (!mc.equals((Object[]) this.fO, (Object[]) aVar.fO) || !mc.equals((Object[]) this.fP, (Object[]) aVar.fP) || !mc.equals((Object[]) this.fQ, (Object[]) aVar.fQ)) {
                return false;
            }
            if (this.fR == null) {
                if (aVar.fR != null) {
                    return false;
                }
            } else if (!this.fR.equals(aVar.fR)) {
                return false;
            }
            if (this.fS == null) {
                if (aVar.fS != null) {
                    return false;
                }
            } else if (!this.fS.equals(aVar.fS)) {
                return false;
            }
            if (this.fT != aVar.fT || this.fU != aVar.fU || !mc.equals((Object[]) this.fV, (Object[]) aVar.fV) || !mc.equals(this.fW, aVar.fW) || this.fX != aVar.fX) {
                return false;
            }
            if (this.amX == null || this.amX.isEmpty()) {
                return aVar.amX == null || aVar.amX.isEmpty();
            }
            return this.amX.equals(aVar.amX);
        }

        public int hashCode() {
            int i = 1231;
            int i2 = 0;
            int hashCode = ((((((this.fU ? 1231 : 1237) + (((((this.fS == null ? 0 : this.fS.hashCode()) + (((this.fR == null ? 0 : this.fR.hashCode()) + (((((((((this.fN == null ? 0 : this.fN.hashCode()) + ((this.type + 527) * 31)) * 31) + mc.hashCode((Object[]) this.fO)) * 31) + mc.hashCode((Object[]) this.fP)) * 31) + mc.hashCode((Object[]) this.fQ)) * 31)) * 31)) * 31) + ((int) (this.fT ^ (this.fT >>> 32)))) * 31)) * 31) + mc.hashCode((Object[]) this.fV)) * 31) + mc.hashCode(this.fW)) * 31;
            if (!this.fX) {
                i = 1237;
            }
            int i3 = (hashCode + i) * 31;
            if (this.amX != null && !this.amX.isEmpty()) {
                i2 = this.amX.hashCode();
            }
            return i3 + i2;
        }

        /* renamed from: l */
        public a b(ly lyVar) throws IOException {
            int i;
            while (true) {
                int nB = lyVar.nB();
                switch (nB) {
                    case 0:
                        break;
                    case 8:
                        int nE = lyVar.nE();
                        switch (nE) {
                            case 1:
                            case 2:
                            case 3:
                            case 4:
                            case 5:
                            case 6:
                            case 7:
                            case 8:
                                this.type = nE;
                                break;
                            default:
                                continue;
                        }
                    case 18:
                        this.fN = lyVar.readString();
                        continue;
                    case 26:
                        int b = mh.b(lyVar, 26);
                        int length = this.fO == null ? 0 : this.fO.length;
                        a[] aVarArr = new a[(b + length)];
                        if (length != 0) {
                            System.arraycopy(this.fO, 0, aVarArr, 0, length);
                        }
                        while (length < aVarArr.length - 1) {
                            aVarArr[length] = new a();
                            lyVar.a(aVarArr[length]);
                            lyVar.nB();
                            length++;
                        }
                        aVarArr[length] = new a();
                        lyVar.a(aVarArr[length]);
                        this.fO = aVarArr;
                        continue;
                    case 34:
                        int b2 = mh.b(lyVar, 34);
                        int length2 = this.fP == null ? 0 : this.fP.length;
                        a[] aVarArr2 = new a[(b2 + length2)];
                        if (length2 != 0) {
                            System.arraycopy(this.fP, 0, aVarArr2, 0, length2);
                        }
                        while (length2 < aVarArr2.length - 1) {
                            aVarArr2[length2] = new a();
                            lyVar.a(aVarArr2[length2]);
                            lyVar.nB();
                            length2++;
                        }
                        aVarArr2[length2] = new a();
                        lyVar.a(aVarArr2[length2]);
                        this.fP = aVarArr2;
                        continue;
                    case 42:
                        int b3 = mh.b(lyVar, 42);
                        int length3 = this.fQ == null ? 0 : this.fQ.length;
                        a[] aVarArr3 = new a[(b3 + length3)];
                        if (length3 != 0) {
                            System.arraycopy(this.fQ, 0, aVarArr3, 0, length3);
                        }
                        while (length3 < aVarArr3.length - 1) {
                            aVarArr3[length3] = new a();
                            lyVar.a(aVarArr3[length3]);
                            lyVar.nB();
                            length3++;
                        }
                        aVarArr3[length3] = new a();
                        lyVar.a(aVarArr3[length3]);
                        this.fQ = aVarArr3;
                        continue;
                    case AdSize.PORTRAIT_AD_HEIGHT:
                        this.fR = lyVar.readString();
                        continue;
                    case 58:
                        this.fS = lyVar.readString();
                        continue;
                    case 64:
                        this.fT = lyVar.nD();
                        continue;
                    case 72:
                        this.fX = lyVar.nF();
                        continue;
                    case 80:
                        int b4 = mh.b(lyVar, 80);
                        int[] iArr = new int[b4];
                        int i2 = 0;
                        int i3 = 0;
                        while (i2 < b4) {
                            if (i2 != 0) {
                                lyVar.nB();
                            }
                            int nE2 = lyVar.nE();
                            switch (nE2) {
                                case 1:
                                case 2:
                                case 3:
                                case 4:
                                case 5:
                                case 6:
                                case 7:
                                case 8:
                                case 9:
                                case 10:
                                case 11:
                                case 12:
                                case 13:
                                case 14:
                                case 15:
                                case 16:
                                case 17:
                                    i = i3 + 1;
                                    iArr[i3] = nE2;
                                    break;
                                default:
                                    i = i3;
                                    break;
                            }
                            i2++;
                            i3 = i;
                        }
                        if (i3 != 0) {
                            int length4 = this.fW == null ? 0 : this.fW.length;
                            if (length4 != 0 || i3 != iArr.length) {
                                int[] iArr2 = new int[(length4 + i3)];
                                if (length4 != 0) {
                                    System.arraycopy(this.fW, 0, iArr2, 0, length4);
                                }
                                System.arraycopy(iArr, 0, iArr2, length4, i3);
                                this.fW = iArr2;
                                break;
                            } else {
                                this.fW = iArr;
                                break;
                            }
                        } else {
                            continue;
                        }
                    case 82:
                        int ex = lyVar.ex(lyVar.nI());
                        int position = lyVar.getPosition();
                        int i4 = 0;
                        while (lyVar.nN() > 0) {
                            switch (lyVar.nE()) {
                                case 1:
                                case 2:
                                case 3:
                                case 4:
                                case 5:
                                case 6:
                                case 7:
                                case 8:
                                case 9:
                                case 10:
                                case 11:
                                case 12:
                                case 13:
                                case 14:
                                case 15:
                                case 16:
                                case 17:
                                    i4++;
                                    break;
                            }
                        }
                        if (i4 != 0) {
                            lyVar.ez(position);
                            int length5 = this.fW == null ? 0 : this.fW.length;
                            int[] iArr3 = new int[(i4 + length5)];
                            if (length5 != 0) {
                                System.arraycopy(this.fW, 0, iArr3, 0, length5);
                            }
                            while (lyVar.nN() > 0) {
                                int nE3 = lyVar.nE();
                                switch (nE3) {
                                    case 1:
                                    case 2:
                                    case 3:
                                    case 4:
                                    case 5:
                                    case 6:
                                    case 7:
                                    case 8:
                                    case 9:
                                    case 10:
                                    case 11:
                                    case 12:
                                    case 13:
                                    case 14:
                                    case 15:
                                    case 16:
                                    case 17:
                                        iArr3[length5] = nE3;
                                        length5++;
                                        break;
                                }
                            }
                            this.fW = iArr3;
                        }
                        lyVar.ey(ex);
                        continue;
                    case AdSize.LARGE_AD_HEIGHT:
                        int b5 = mh.b(lyVar, 90);
                        int length6 = this.fV == null ? 0 : this.fV.length;
                        a[] aVarArr4 = new a[(b5 + length6)];
                        if (length6 != 0) {
                            System.arraycopy(this.fV, 0, aVarArr4, 0, length6);
                        }
                        while (length6 < aVarArr4.length - 1) {
                            aVarArr4[length6] = new a();
                            lyVar.a(aVarArr4[length6]);
                            lyVar.nB();
                            length6++;
                        }
                        aVarArr4[length6] = new a();
                        lyVar.a(aVarArr4[length6]);
                        this.fV = aVarArr4;
                        continue;
                    case 96:
                        this.fU = lyVar.nF();
                        continue;
                    default:
                        if (!a(lyVar, nB)) {
                            break;
                        } else {
                            continue;
                        }
                }
            }
            return this;
        }

        public a s() {
            this.type = 1;
            this.fN = "";
            this.fO = r();
            this.fP = r();
            this.fQ = r();
            this.fR = "";
            this.fS = "";
            this.fT = 0;
            this.fU = false;
            this.fV = r();
            this.fW = mh.and;
            this.fX = false;
            this.amX = null;
            this.anb = -1;
            return this;
        }
    }
}
