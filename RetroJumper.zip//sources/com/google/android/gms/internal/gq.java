package com.google.android.gms.internal;

import org.json.JSONObject;

public interface gq {
    void a(long j, int i, JSONObject jSONObject);

    void n(long j);
}
