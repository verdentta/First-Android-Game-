package com.google.android.gms.internal;

import java.io.IOException;

public interface iv {

    public static final class a extends ma<a> {
        public C0060a[] Uy;

        /* renamed from: com.google.android.gms.internal.iv$a$a  reason: collision with other inner class name */
        public static final class C0060a extends ma<C0060a> {
            private static volatile C0060a[] Uz;
            public String UA;
            public String UB;
            public int viewId;

            public C0060a() {
                iS();
            }

            public static C0060a[] iR() {
                if (Uz == null) {
                    synchronized (mc.ana) {
                        if (Uz == null) {
                            Uz = new C0060a[0];
                        }
                    }
                }
                return Uz;
            }

            public void a(lz lzVar) throws IOException {
                if (!this.UA.equals("")) {
                    lzVar.b(1, this.UA);
                }
                if (!this.UB.equals("")) {
                    lzVar.b(2, this.UB);
                }
                if (this.viewId != 0) {
                    lzVar.p(3, this.viewId);
                }
                super.a(lzVar);
            }

            /* access modifiers changed from: protected */
            public int c() {
                int c = super.c();
                if (!this.UA.equals("")) {
                    c += lz.h(1, this.UA);
                }
                if (!this.UB.equals("")) {
                    c += lz.h(2, this.UB);
                }
                return this.viewId != 0 ? c + lz.r(3, this.viewId) : c;
            }

            public boolean equals(Object o) {
                if (o == this) {
                    return true;
                }
                if (!(o instanceof C0060a)) {
                    return false;
                }
                C0060a aVar = (C0060a) o;
                if (this.UA == null) {
                    if (aVar.UA != null) {
                        return false;
                    }
                } else if (!this.UA.equals(aVar.UA)) {
                    return false;
                }
                if (this.UB == null) {
                    if (aVar.UB != null) {
                        return false;
                    }
                } else if (!this.UB.equals(aVar.UB)) {
                    return false;
                }
                if (this.viewId != aVar.viewId) {
                    return false;
                }
                if (this.amX == null || this.amX.isEmpty()) {
                    return aVar.amX == null || aVar.amX.isEmpty();
                }
                return this.amX.equals(aVar.amX);
            }

            public int hashCode() {
                int i = 0;
                int hashCode = ((((this.UB == null ? 0 : this.UB.hashCode()) + (((this.UA == null ? 0 : this.UA.hashCode()) + 527) * 31)) * 31) + this.viewId) * 31;
                if (this.amX != null && !this.amX.isEmpty()) {
                    i = this.amX.hashCode();
                }
                return hashCode + i;
            }

            public C0060a iS() {
                this.UA = "";
                this.UB = "";
                this.viewId = 0;
                this.amX = null;
                this.anb = -1;
                return this;
            }

            /* renamed from: o */
            public C0060a b(ly lyVar) throws IOException {
                while (true) {
                    int nB = lyVar.nB();
                    switch (nB) {
                        case 0:
                            break;
                        case 10:
                            this.UA = lyVar.readString();
                            continue;
                        case 18:
                            this.UB = lyVar.readString();
                            continue;
                        case 24:
                            this.viewId = lyVar.nE();
                            continue;
                        default:
                            if (!a(lyVar, nB)) {
                                break;
                            } else {
                                continue;
                            }
                    }
                }
                return this;
            }
        }

        public a() {
            iQ();
        }

        public void a(lz lzVar) throws IOException {
            if (this.Uy != null && this.Uy.length > 0) {
                for (C0060a aVar : this.Uy) {
                    if (aVar != null) {
                        lzVar.a(1, (me) aVar);
                    }
                }
            }
            super.a(lzVar);
        }

        /* access modifiers changed from: protected */
        public int c() {
            int c = super.c();
            if (this.Uy != null && this.Uy.length > 0) {
                for (C0060a aVar : this.Uy) {
                    if (aVar != null) {
                        c += lz.b(1, (me) aVar);
                    }
                }
            }
            return c;
        }

        public boolean equals(Object o) {
            if (o == this) {
                return true;
            }
            if (!(o instanceof a)) {
                return false;
            }
            a aVar = (a) o;
            if (!mc.equals((Object[]) this.Uy, (Object[]) aVar.Uy)) {
                return false;
            }
            if (this.amX == null || this.amX.isEmpty()) {
                return aVar.amX == null || aVar.amX.isEmpty();
            }
            return this.amX.equals(aVar.amX);
        }

        public int hashCode() {
            return ((this.amX == null || this.amX.isEmpty()) ? 0 : this.amX.hashCode()) + ((mc.hashCode((Object[]) this.Uy) + 527) * 31);
        }

        public a iQ() {
            this.Uy = C0060a.iR();
            this.amX = null;
            this.anb = -1;
            return this;
        }

        /* renamed from: n */
        public a b(ly lyVar) throws IOException {
            while (true) {
                int nB = lyVar.nB();
                switch (nB) {
                    case 0:
                        break;
                    case 10:
                        int b = mh.b(lyVar, 10);
                        int length = this.Uy == null ? 0 : this.Uy.length;
                        C0060a[] aVarArr = new C0060a[(b + length)];
                        if (length != 0) {
                            System.arraycopy(this.Uy, 0, aVarArr, 0, length);
                        }
                        while (length < aVarArr.length - 1) {
                            aVarArr[length] = new C0060a();
                            lyVar.a(aVarArr[length]);
                            lyVar.nB();
                            length++;
                        }
                        aVarArr[length] = new C0060a();
                        lyVar.a(aVarArr[length]);
                        this.Uy = aVarArr;
                        continue;
                    default:
                        if (!a(lyVar, nB)) {
                            break;
                        } else {
                            continue;
                        }
                }
            }
            return this;
        }
    }
}
