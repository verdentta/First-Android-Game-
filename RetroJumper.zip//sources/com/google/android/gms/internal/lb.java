package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.b;
import com.google.android.gms.internal.ks;
import java.util.HashSet;
import java.util.Set;

public class lb implements Parcelable.Creator<ks.g> {
    static void a(ks.g gVar, Parcel parcel, int i) {
        int C = b.C(parcel);
        Set<Integer> kk = gVar.kk();
        if (kk.contains(1)) {
            b.c(parcel, 1, gVar.getVersionCode());
        }
        if (kk.contains(2)) {
            b.a(parcel, 2, gVar.isPrimary());
        }
        if (kk.contains(3)) {
            b.a(parcel, 3, gVar.getValue(), true);
        }
        b.G(parcel, C);
    }

    /* renamed from: bO */
    public ks.g createFromParcel(Parcel parcel) {
        boolean z = false;
        int B = a.B(parcel);
        HashSet hashSet = new HashSet();
        String str = null;
        int i = 0;
        while (parcel.dataPosition() < B) {
            int A = a.A(parcel);
            switch (a.ar(A)) {
                case 1:
                    i = a.g(parcel, A);
                    hashSet.add(1);
                    break;
                case 2:
                    z = a.c(parcel, A);
                    hashSet.add(2);
                    break;
                case 3:
                    str = a.o(parcel, A);
                    hashSet.add(3);
                    break;
                default:
                    a.b(parcel, A);
                    break;
            }
        }
        if (parcel.dataPosition() == B) {
            return new ks.g(hashSet, i, z, str);
        }
        throw new a.C0010a("Overread allowed size end=" + B, parcel);
    }

    /* renamed from: dl */
    public ks.g[] newArray(int i) {
        return new ks.g[i];
    }
}
