package com.google.android.gms.internal;

import com.google.android.gms.drive.metadata.MetadataField;
import com.google.android.gms.drive.metadata.internal.b;
import com.google.android.gms.drive.metadata.internal.f;

public class iu {
    public static final MetadataField<Integer> KC = new f("contentAvailability", 4300000);
    public static final MetadataField<Boolean> KD = new b("isPinnable", 4300000);
}
