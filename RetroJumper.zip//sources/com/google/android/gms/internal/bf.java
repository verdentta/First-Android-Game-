package com.google.android.gms.internal;

public interface bf {
    void b(boolean z);
}
