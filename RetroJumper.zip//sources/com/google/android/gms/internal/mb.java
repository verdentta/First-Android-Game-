package com.google.android.gms.internal;

import com.google.android.gms.internal.ma;
import java.io.IOException;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

public class mb<M extends ma<M>, T> {
    protected final Class<T> amY;
    protected final boolean amZ;
    protected final int tag;
    protected final int type;

    private mb(int i, Class<T> cls, int i2, boolean z) {
        this.type = i;
        this.amY = cls;
        this.tag = i2;
        this.amZ = z;
    }

    public static <M extends ma<M>, T extends me> mb<M, T> a(int i, Class<T> cls, int i2) {
        return new mb<>(i, cls, i2, false);
    }

    /* access modifiers changed from: protected */
    public void a(mg mgVar, List<Object> list) {
        list.add(u(ly.p(mgVar.anc)));
    }

    /* access modifiers changed from: protected */
    public boolean eM(int i) {
        return i == this.tag;
    }

    /* access modifiers changed from: package-private */
    public final T i(List<mg> list) {
        if (list == null) {
            return null;
        }
        if (this.amZ) {
            ArrayList arrayList = new ArrayList();
            for (int i = 0; i < list.size(); i++) {
                mg mgVar = list.get(i);
                if (eM(mgVar.tag) && mgVar.anc.length != 0) {
                    a(mgVar, arrayList);
                }
            }
            int size = arrayList.size();
            if (size == 0) {
                return null;
            }
            T cast = this.amY.cast(Array.newInstance(this.amY.getComponentType(), size));
            for (int i2 = 0; i2 < size; i2++) {
                Array.set(cast, i2, arrayList.get(i2));
            }
            return cast;
        }
        int size2 = list.size() - 1;
        mg mgVar2 = null;
        while (mgVar2 == null && size2 >= 0) {
            mg mgVar3 = list.get(size2);
            if (!eM(mgVar3.tag) || mgVar3.anc.length == 0) {
                mgVar3 = mgVar2;
            }
            size2--;
            mgVar2 = mgVar3;
        }
        if (mgVar2 == null) {
            return null;
        }
        return this.amY.cast(u(ly.p(mgVar2.anc)));
    }

    /* access modifiers changed from: protected */
    public Object u(ly lyVar) {
        Class<?> componentType = this.amZ ? this.amY.getComponentType() : this.amY;
        try {
            switch (this.type) {
                case 10:
                    me meVar = (me) componentType.newInstance();
                    lyVar.a(meVar, mh.eO(this.tag));
                    return meVar;
                case 11:
                    me meVar2 = (me) componentType.newInstance();
                    lyVar.a(meVar2);
                    return meVar2;
                default:
                    throw new IllegalArgumentException("Unknown type " + this.type);
            }
        } catch (InstantiationException e) {
            throw new IllegalArgumentException("Error creating instance of class " + componentType, e);
        } catch (IllegalAccessException e2) {
            throw new IllegalArgumentException("Error creating instance of class " + componentType, e2);
        } catch (IOException e3) {
            throw new IllegalArgumentException("Error reading extension field", e3);
        }
    }
}
