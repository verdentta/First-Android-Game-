package com.google.android.gms.internal;

import android.os.ParcelFileDescriptor;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.api.a;
import com.google.android.gms.internal.fv;

public abstract class fw<T> extends fv.a {
    protected a.d<T> yu;

    public fw(a.d<T> dVar) {
        this.yu = dVar;
    }

    public void a(Status status) {
    }

    public void a(Status status, ParcelFileDescriptor parcelFileDescriptor) {
    }

    public void a(Status status, boolean z) {
    }
}
