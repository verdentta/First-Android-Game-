package com.google.android.gms.internal;

import android.location.Location;

public interface bi {
    Location a(long j);

    void init();
}
