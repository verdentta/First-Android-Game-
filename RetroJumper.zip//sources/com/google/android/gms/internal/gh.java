package com.google.android.gms.internal;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.RemoteException;
import android.text.TextUtils;
import com.google.android.gms.cast.ApplicationMetadata;
import com.google.android.gms.cast.Cast;
import com.google.android.gms.cast.CastDevice;
import com.google.android.gms.cast.LaunchOptions;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.api.a;
import com.google.android.gms.internal.gl;
import com.google.android.gms.internal.gm;
import com.google.android.gms.internal.hb;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

public final class gh extends hb<gl> {
    /* access modifiers changed from: private */
    public static final gn BG = new gn("CastClientImpl");
    /* access modifiers changed from: private */
    public static final Object Ca = new Object();
    /* access modifiers changed from: private */
    public static final Object Cb = new Object();
    private double AP = 0.0d;
    private boolean AQ = false;
    /* access modifiers changed from: private */
    public final Cast.Listener Ae;
    /* access modifiers changed from: private */
    public ApplicationMetadata BH = null;
    /* access modifiers changed from: private */
    public final CastDevice BI;
    private final gm BJ;
    /* access modifiers changed from: private */
    public final Map<String, Cast.MessageReceivedCallback> BK = new HashMap();
    private final long BL;
    private String BM = null;
    private boolean BN;
    private boolean BO;
    /* access modifiers changed from: private */
    public boolean BP = false;
    /* access modifiers changed from: private */
    public AtomicBoolean BQ = new AtomicBoolean(false);
    private int BR = -1;
    private final AtomicLong BS = new AtomicLong(0);
    /* access modifiers changed from: private */
    public String BT;
    /* access modifiers changed from: private */
    public String BU;
    private Bundle BV;
    /* access modifiers changed from: private */
    public Map<Long, a.d<Status>> BW = new HashMap();
    private b BX = new b();
    /* access modifiers changed from: private */
    public a.d<Cast.ApplicationConnectionResult> BY;
    /* access modifiers changed from: private */
    public a.d<Status> BZ;
    /* access modifiers changed from: private */
    public final Handler mHandler;

    private static final class a implements Cast.ApplicationConnectionResult {
        private final ApplicationMetadata Ci;
        private final String Cj;
        private final boolean Ck;
        private final String rR;
        private final Status yz;

        public a(Status status) {
            this(status, (ApplicationMetadata) null, (String) null, (String) null, false);
        }

        public a(Status status, ApplicationMetadata applicationMetadata, String str, String str2, boolean z) {
            this.yz = status;
            this.Ci = applicationMetadata;
            this.Cj = str;
            this.rR = str2;
            this.Ck = z;
        }

        public ApplicationMetadata getApplicationMetadata() {
            return this.Ci;
        }

        public String getApplicationStatus() {
            return this.Cj;
        }

        public String getSessionId() {
            return this.rR;
        }

        public Status getStatus() {
            return this.yz;
        }

        public boolean getWasLaunched() {
            return this.Ck;
        }
    }

    private class b implements GoogleApiClient.OnConnectionFailedListener {
        private b() {
        }

        public void onConnectionFailed(ConnectionResult result) {
            gh.this.ei();
        }
    }

    public gh(Context context, Looper looper, CastDevice castDevice, long j, Cast.Listener listener, GoogleApiClient.ConnectionCallbacks connectionCallbacks, GoogleApiClient.OnConnectionFailedListener onConnectionFailedListener) {
        super(context, looper, connectionCallbacks, onConnectionFailedListener, (String[]) null);
        this.BI = castDevice;
        this.Ae = listener;
        this.BL = j;
        this.mHandler = new Handler(looper);
        registerConnectionFailedListener((GoogleApiClient.OnConnectionFailedListener) this.BX);
        this.BJ = new gm.a() {
            private boolean X(int i) {
                synchronized (gh.Cb) {
                    if (gh.this.BZ == null) {
                        return false;
                    }
                    gh.this.BZ.a(new Status(i));
                    a.d unused = gh.this.BZ = null;
                    return true;
                }
            }

            private void b(long j, int i) {
                a.d dVar;
                synchronized (gh.this.BW) {
                    dVar = (a.d) gh.this.BW.remove(Long.valueOf(j));
                }
                if (dVar != null) {
                    dVar.a(new Status(i));
                }
            }

            public void T(int i) {
                gh.BG.b("ICastDeviceControllerListener.onDisconnected: %d", Integer.valueOf(i));
                boolean unused = gh.this.BP = false;
                gh.this.BQ.set(false);
                ApplicationMetadata unused2 = gh.this.BH = null;
                if (i != 0) {
                    gh.this.an(2);
                }
            }

            public void U(int i) {
                synchronized (gh.Ca) {
                    if (gh.this.BY != null) {
                        gh.this.BY.a(new a(new Status(i)));
                        a.d unused = gh.this.BY = null;
                    }
                }
            }

            public void V(int i) {
                X(i);
            }

            public void W(int i) {
                X(i);
            }

            public void a(ApplicationMetadata applicationMetadata, String str, String str2, boolean z) {
                ApplicationMetadata unused = gh.this.BH = applicationMetadata;
                String unused2 = gh.this.BT = applicationMetadata.getApplicationId();
                String unused3 = gh.this.BU = str2;
                synchronized (gh.Ca) {
                    if (gh.this.BY != null) {
                        gh.this.BY.a(new a(new Status(0), applicationMetadata, str, str2, z));
                        a.d unused4 = gh.this.BY = null;
                    }
                }
            }

            public void a(String str, double d, boolean z) {
                gh.BG.b("Deprecated callback: \"onStatusreceived\"", new Object[0]);
            }

            public void a(String str, long j) {
                b(j, 0);
            }

            public void a(String str, long j, int i) {
                b(j, i);
            }

            public void b(final ge geVar) {
                gh.BG.b("onApplicationStatusChanged", new Object[0]);
                gh.this.mHandler.post(new Runnable() {
                    public void run() {
                        gh.this.a(geVar);
                    }
                });
            }

            public void b(final gj gjVar) {
                gh.BG.b("onDeviceStatusChanged", new Object[0]);
                gh.this.mHandler.post(new Runnable() {
                    public void run() {
                        gh.this.a(gjVar);
                    }
                });
            }

            public void b(String str, byte[] bArr) {
                gh.BG.b("IGNORING: Receive (type=binary, ns=%s) <%d bytes>", str, Integer.valueOf(bArr.length));
            }

            public void g(final String str, final String str2) {
                gh.BG.b("Receive (type=text, ns=%s) %s", str, str2);
                gh.this.mHandler.post(new Runnable() {
                    public void run() {
                        Cast.MessageReceivedCallback messageReceivedCallback;
                        synchronized (gh.this.BK) {
                            messageReceivedCallback = (Cast.MessageReceivedCallback) gh.this.BK.get(str);
                        }
                        if (messageReceivedCallback != null) {
                            messageReceivedCallback.onMessageReceived(gh.this.BI, str, str2);
                            return;
                        }
                        gh.BG.b("Discarded message for unknown namespace '%s'", str);
                    }
                });
            }

            public void onApplicationDisconnected(final int statusCode) {
                String unused = gh.this.BT = null;
                String unused2 = gh.this.BU = null;
                X(statusCode);
                if (gh.this.Ae != null) {
                    gh.this.mHandler.post(new Runnable() {
                        public void run() {
                            if (gh.this.Ae != null) {
                                gh.this.Ae.onApplicationDisconnected(statusCode);
                            }
                        }
                    });
                }
            }
        };
    }

    /* access modifiers changed from: private */
    public void a(ge geVar) {
        boolean z;
        String ec = geVar.ec();
        if (!gi.a(ec, this.BM)) {
            this.BM = ec;
            z = true;
        } else {
            z = false;
        }
        BG.b("hasChanged=%b, mFirstApplicationStatusUpdate=%b", Boolean.valueOf(z), Boolean.valueOf(this.BN));
        if (this.Ae != null && (z || this.BN)) {
            this.Ae.onApplicationStatusChanged();
        }
        this.BN = false;
    }

    /* access modifiers changed from: private */
    public void a(gj gjVar) {
        boolean z;
        boolean z2;
        double eh = gjVar.eh();
        if (eh == Double.NaN || eh == this.AP) {
            z = false;
        } else {
            this.AP = eh;
            z = true;
        }
        boolean en = gjVar.en();
        if (en != this.AQ) {
            this.AQ = en;
            z = true;
        }
        BG.b("hasVolumeChanged=%b, mFirstDeviceStatusUpdate=%b", Boolean.valueOf(z), Boolean.valueOf(this.BO));
        if (this.Ae != null && (z || this.BO)) {
            this.Ae.onVolumeChanged();
        }
        int eo = gjVar.eo();
        if (eo != this.BR) {
            this.BR = eo;
            z2 = true;
        } else {
            z2 = false;
        }
        BG.b("hasActiveInputChanged=%b, mFirstDeviceStatusUpdate=%b", Boolean.valueOf(z2), Boolean.valueOf(this.BO));
        if (this.Ae != null && (z2 || this.BO)) {
            this.Ae.O(this.BR);
        }
        this.BO = false;
    }

    private void c(a.d<Cast.ApplicationConnectionResult> dVar) {
        synchronized (Ca) {
            if (this.BY != null) {
                this.BY.a(new a(new Status(2002)));
            }
            this.BY = dVar;
        }
    }

    private void e(a.d<Status> dVar) {
        synchronized (Cb) {
            if (this.BZ != null) {
                dVar.a(new Status(2001));
            } else {
                this.BZ = dVar;
            }
        }
    }

    /* access modifiers changed from: private */
    public void ei() {
        BG.b("removing all MessageReceivedCallbacks", new Object[0]);
        synchronized (this.BK) {
            this.BK.clear();
        }
    }

    private void ej() throws IllegalStateException {
        if (!this.BP || this.BQ.get()) {
            throw new IllegalStateException("Not connected to a device");
        }
    }

    /* access modifiers changed from: protected */
    /* renamed from: G */
    public gl x(IBinder iBinder) {
        return gl.a.H(iBinder);
    }

    public void a(double d) throws IllegalArgumentException, IllegalStateException, RemoteException {
        if (Double.isInfinite(d) || Double.isNaN(d)) {
            throw new IllegalArgumentException("Volume cannot be " + d);
        }
        ((gl) ft()).a(d, this.AP, this.AQ);
    }

    /* access modifiers changed from: protected */
    public void a(int i, IBinder iBinder, Bundle bundle) {
        BG.b("in onPostInitHandler; statusCode=%d", Integer.valueOf(i));
        if (i == 0 || i == 1001) {
            this.BP = true;
            this.BN = true;
            this.BO = true;
        } else {
            this.BP = false;
        }
        if (i == 1001) {
            this.BV = new Bundle();
            this.BV.putBoolean(Cast.EXTRA_APP_NO_LONGER_RUNNING, true);
            i = 0;
        }
        super.a(i, iBinder, bundle);
    }

    /* access modifiers changed from: protected */
    public void a(hi hiVar, hb.e eVar) throws RemoteException {
        Bundle bundle = new Bundle();
        BG.b("getServiceFromBroker(): mLastApplicationId=%s, mLastSessionId=%s", this.BT, this.BU);
        this.BI.putInBundle(bundle);
        bundle.putLong("com.google.android.gms.cast.EXTRA_CAST_FLAGS", this.BL);
        if (this.BT != null) {
            bundle.putString("last_application_id", this.BT);
            if (this.BU != null) {
                bundle.putString("last_session_id", this.BU);
            }
        }
        hiVar.a((hh) eVar, (int) GooglePlayServicesUtil.GOOGLE_PLAY_SERVICES_VERSION_CODE, getContext().getPackageName(), this.BJ.asBinder(), bundle);
    }

    public void a(String str, Cast.MessageReceivedCallback messageReceivedCallback) throws IllegalArgumentException, IllegalStateException, RemoteException {
        gi.ak(str);
        aj(str);
        if (messageReceivedCallback != null) {
            synchronized (this.BK) {
                this.BK.put(str, messageReceivedCallback);
            }
            ((gl) ft()).an(str);
        }
    }

    public void a(String str, LaunchOptions launchOptions, a.d<Cast.ApplicationConnectionResult> dVar) throws IllegalStateException, RemoteException {
        c(dVar);
        ((gl) ft()).a(str, launchOptions);
    }

    public void a(String str, a.d<Status> dVar) throws IllegalStateException, RemoteException {
        e(dVar);
        ((gl) ft()).am(str);
    }

    public void a(String str, String str2, a.d<Status> dVar) throws IllegalArgumentException, IllegalStateException, RemoteException {
        if (TextUtils.isEmpty(str2)) {
            throw new IllegalArgumentException("The message payload cannot be null or empty");
        } else if (str2.length() > 65536) {
            throw new IllegalArgumentException("Message exceeds maximum size");
        } else {
            gi.ak(str);
            ej();
            long incrementAndGet = this.BS.incrementAndGet();
            ((gl) ft()).a(str, str2, incrementAndGet);
            this.BW.put(Long.valueOf(incrementAndGet), dVar);
        }
    }

    public void a(String str, boolean z, a.d<Cast.ApplicationConnectionResult> dVar) throws IllegalStateException, RemoteException {
        c(dVar);
        ((gl) ft()).e(str, z);
    }

    public void aj(String str) throws IllegalArgumentException, RemoteException {
        Cast.MessageReceivedCallback remove;
        if (TextUtils.isEmpty(str)) {
            throw new IllegalArgumentException("Channel namespace cannot be null or empty");
        }
        synchronized (this.BK) {
            remove = this.BK.remove(str);
        }
        if (remove != null) {
            try {
                ((gl) ft()).ao(str);
            } catch (IllegalStateException e) {
                BG.a(e, "Error unregistering namespace (%s): %s", str, e.getMessage());
            }
        }
    }

    public void b(String str, String str2, a.d<Cast.ApplicationConnectionResult> dVar) throws IllegalStateException, RemoteException {
        c(dVar);
        ((gl) ft()).h(str, str2);
    }

    /* access modifiers changed from: protected */
    public String bu() {
        return "com.google.android.gms.cast.service.BIND_CAST_DEVICE_CONTROLLER_SERVICE";
    }

    /* access modifiers changed from: protected */
    public String bv() {
        return "com.google.android.gms.cast.internal.ICastDeviceController";
    }

    public void d(a.d<Status> dVar) throws IllegalStateException, RemoteException {
        e(dVar);
        ((gl) ft()).ep();
    }

    public void disconnect() {
        BG.b("disconnect(); mDisconnecting=%b, isConnected=%b", Boolean.valueOf(this.BQ.get()), Boolean.valueOf(isConnected()));
        if (this.BQ.getAndSet(true)) {
            BG.b("mDisconnecting is set, so short-circuiting", new Object[0]);
            return;
        }
        ei();
        try {
            if (isConnected() || isConnecting()) {
                ((gl) ft()).disconnect();
            }
        } catch (RemoteException e) {
            BG.a(e, "Error while disconnecting the controller interface: %s", e.getMessage());
        } finally {
            super.disconnect();
        }
    }

    public Bundle ef() {
        if (this.BV == null) {
            return super.ef();
        }
        Bundle bundle = this.BV;
        this.BV = null;
        return bundle;
    }

    public void eg() throws IllegalStateException, RemoteException {
        ((gl) ft()).eg();
    }

    public double eh() throws IllegalStateException {
        ej();
        return this.AP;
    }

    public ApplicationMetadata getApplicationMetadata() throws IllegalStateException {
        ej();
        return this.BH;
    }

    public String getApplicationStatus() throws IllegalStateException {
        ej();
        return this.BM;
    }

    public boolean isMute() throws IllegalStateException {
        ej();
        return this.AQ;
    }

    public void y(boolean z) throws IllegalStateException, RemoteException {
        ((gl) ft()).a(z, this.AP, this.AQ);
    }
}
