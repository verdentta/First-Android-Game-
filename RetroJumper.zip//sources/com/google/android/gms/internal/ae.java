package com.google.android.gms.internal;

import org.json.JSONObject;

public interface ae {

    public interface a {
        void aE();
    }

    void a(a aVar);

    void a(String str, bc bcVar);

    void a(String str, JSONObject jSONObject);

    void d(String str);

    void e(String str);

    void pause();

    void resume();
}
