package com.google.android.gms.internal;

import android.content.Context;
import android.os.Bundle;
import android.os.RemoteException;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesClient;
import com.google.android.gms.internal.dp;

public abstract class dq extends em {
    private final ds ne;
    private final dp.a pT;

    public static final class a extends dq {
        private final Context mContext;

        public a(Context context, ds dsVar, dp.a aVar) {
            super(dsVar, aVar);
            this.mContext = context;
        }

        public void bs() {
        }

        public dw bt() {
            return dx.a(this.mContext, new ay(), (bi) new bj(), (ed) new ee());
        }
    }

    public static final class b extends dq implements GooglePlayServicesClient.ConnectionCallbacks, GooglePlayServicesClient.OnConnectionFailedListener {
        private final Object ls = new Object();
        private final dp.a pT;
        private final dr pU;

        public b(Context context, ds dsVar, dp.a aVar) {
            super(dsVar, aVar);
            this.pT = aVar;
            this.pU = new dr(context, this, this, dsVar.kQ.sy);
            this.pU.connect();
        }

        public void bs() {
            synchronized (this.ls) {
                if (this.pU.isConnected() || this.pU.isConnecting()) {
                    this.pU.disconnect();
                }
            }
        }

        public dw bt() {
            dw dwVar;
            synchronized (this.ls) {
                try {
                    dwVar = this.pU.bw();
                } catch (IllegalStateException e) {
                    dwVar = null;
                }
            }
            return dwVar;
        }

        public void onConnected(Bundle connectionHint) {
            start();
        }

        public void onConnectionFailed(ConnectionResult result) {
            this.pT.a(new du(0));
        }

        public void onDisconnected() {
            eu.z("Disconnected from remote ad request service.");
        }
    }

    public dq(ds dsVar, dp.a aVar) {
        this.ne = dsVar;
        this.pT = aVar;
    }

    private static du a(dw dwVar, ds dsVar) {
        try {
            return dwVar.b(dsVar);
        } catch (RemoteException e) {
            eu.c("Could not fetch ad response from ad request service.", e);
            return null;
        } catch (NullPointerException e2) {
            eu.c("Could not fetch ad response from ad request service due to an Exception.", e2);
            return null;
        } catch (SecurityException e3) {
            eu.c("Could not fetch ad response from ad request service due to an Exception.", e3);
            return null;
        }
    }

    /* JADX INFO: finally extract failed */
    public final void bh() {
        du a2;
        try {
            dw bt = bt();
            if (bt == null) {
                a2 = new du(0);
            } else {
                a2 = a(bt, this.ne);
                if (a2 == null) {
                    a2 = new du(0);
                }
            }
            bs();
            this.pT.a(a2);
        } catch (Throwable th) {
            bs();
            throw th;
        }
    }

    public abstract void bs();

    public abstract dw bt();

    public final void onStop() {
        bs();
    }
}
