package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.b;
import com.google.android.gms.internal.hy;
import com.google.android.gms.internal.ib;

public class ia implements Parcelable.Creator<ib.b> {
    static void a(ib.b bVar, Parcel parcel, int i) {
        int C = b.C(parcel);
        b.c(parcel, 1, bVar.versionCode);
        b.a(parcel, 2, bVar.eM, false);
        b.a(parcel, 3, (Parcelable) bVar.Hp, i, false);
        b.G(parcel, C);
    }

    /* renamed from: I */
    public ib.b createFromParcel(Parcel parcel) {
        hy.a aVar = null;
        int B = a.B(parcel);
        int i = 0;
        String str = null;
        while (parcel.dataPosition() < B) {
            int A = a.A(parcel);
            switch (a.ar(A)) {
                case 1:
                    i = a.g(parcel, A);
                    break;
                case 2:
                    str = a.o(parcel, A);
                    break;
                case 3:
                    aVar = (hy.a) a.a(parcel, A, hy.a.CREATOR);
                    break;
                default:
                    a.b(parcel, A);
                    break;
            }
        }
        if (parcel.dataPosition() == B) {
            return new ib.b(i, str, aVar);
        }
        throw new a.C0010a("Overread allowed size end=" + B, parcel);
    }

    /* renamed from: ax */
    public ib.b[] newArray(int i) {
        return new ib.b[i];
    }
}
